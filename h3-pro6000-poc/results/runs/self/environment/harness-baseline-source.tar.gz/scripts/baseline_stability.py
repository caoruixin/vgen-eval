"""Server-only priority run: complete frozen baseline, then separate 60-minute stability."""
import platform,subprocess
from pathlib import Path
from common import ROOT,append,dump,load,utcnow
from budget import Ledger
if platform.system()!='Linux':raise SystemExit('Server only')
r=ROOT/'runs/self';log=str(r/'deploy/server-bf16-cpubind.log')
expected=[c['request_id'] for c in load(ROOT/'cases/matrix.lock.json')['requests'] if c['phase']=='baseline']
previous=-1
for window in range(3):
    rows=[load(r/'records'/(key+'.json')) for key in expected if (r/'records'/(key+'.json')).exists()]
    valid=sum(x.get('status')=='validated' for x in rows)
    if valid==len(expected):break
    if valid==previous or any(x.get('status')!='validated' for x in rows) or (r/'STOP_SUBMISSIONS').exists():raise SystemExit('Baseline stopped; no automatic resubmission')
    previous=valid
    Ledger(ROOT/'private/ledger.json').guard(next_gpu_seconds=2100)
    result=subprocess.run(['python3','scripts/run.py','--phase','baseline','--run-dir','runs/self','--execute','--skip-existing-completed','--server-log',log],cwd=ROOT)
    if result.returncode:raise SystemExit('Baseline runner failed; inspect evidence')
rows=[load(r/'records'/(key+'.json')) for key in expected if (r/'records'/(key+'.json')).exists()]
if len(rows)!=42 or any(x.get('status')!='validated' for x in rows):raise SystemExit('Incomplete baseline; optional work not started')
dump(r/'BASELINE_COMPLETE.json',{'utc':utcnow(),'n':42,'technical_valid':42})
Ledger(ROOT/'private/ledger.json').guard(next_gpu_seconds=3900)
result=subprocess.run(['python3','scripts/run.py','--phase','stability','--run-dir','runs/self','--execute','--server-log',log],cwd=ROOT)
sr=[load(p) for p in (r/'records').glob('stability-*.json')]
dump(r/'STABILITY_FINISHED.json',{'utc':utcnow(),'runner_exit_code':result.returncode,'n':len(sr),'technical_valid':sum(x.get('status')=='validated' for x in sr),'other_outcomes':[{'request_id':x['request_id'],'status':x.get('status'),'error':x.get('error'),'cancellation_response':x.get('cancellation_response')} for x in sr if x.get('status')!='validated']})
print('Priority baseline and separate stability invocation finished. Controller must review before optional tests.')
