"""Observe completed serial denoising progress without modifying model execution."""
from pathlib import Path
import re
from common import dump,sha256

ANSI=re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
COUNTER=re.compile(r'(?<!\d)(\d+)/(\d+)\s*\[')

def completed_updates(text,expected,overlapping=False):
    if overlapping:return None
    pairs=[(int(a),int(b)) for a,b in COUNTER.findall(ANSI.sub('',text))]
    return expected if any(a==b==expected for a,b in pairs) else None

def begin(server_log):
    p=Path(server_log) if server_log else None
    return p.stat().st_size if p and p.is_file() else None

def finish(server_log,offset,record,run_dir):
    if not server_log or offset is None:return
    p=Path(server_log)
    if not p.is_file() or p.stat().st_size<offset:return
    end=p.stat().st_size
    if end-offset>16*1024*1024:
        record['actual_denoise_updates_source']='log span >16MiB; full log retained, no counter inferred';return
    with p.open('rb') as f:f.seek(offset);raw=f.read(end-offset)
    evidence=Path(run_dir)/'outputs'/record['request_id'];evidence.mkdir(parents=True,exist_ok=True)
    excerpt=evidence/'server-progress.txt';excerpt.write_bytes(raw)
    overlap=record['phase'].startswith('concurrency')
    updates=completed_updates(raw.decode(errors='replace'),record['requested_num_inference_steps'],overlap)
    if record.get('status')!='validated':updates=None
    record['actual_denoise_updates']=updates
    record['actual_denoise_updates_source']=str(excerpt.relative_to(run_dir)) if updates is not None else 'not attributed: overlapping requests or no completed counter'
    dump(evidence/'server-progress-evidence.json',{'source_log':str(p),'start_byte':offset,'end_byte':end,'excerpt_sha256':sha256(excerpt),'actual_denoise_updates_observed':updates,'overlapping_requests':overlap,'method':'Completed N/N denoising progress inside serial request byte span; not network forward-pass count or configured-step inference'})
