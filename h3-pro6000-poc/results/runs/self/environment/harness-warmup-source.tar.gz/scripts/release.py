"""Normal server release requires the laptop's verified copy evidence."""
import argparse
from pathlib import Path
import platform

from common import ROOT,append,dump,load,require_authorization,sha256,utcnow
from guardian import destroy

if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--run-dir",type=Path,required=True);p.add_argument("--rental",type=Path,required=True);p.add_argument("--verified-copy",type=Path,required=True);p.add_argument("--authorization",type=Path,default=ROOT/"private/authorization.json");p.add_argument("--execute",action="store_true");a=p.parse_args()
    v=load(a.verified_copy);manifest=a.run_dir/"cost/archive-manifest.json"
    if not v.get("passed") or v.get("manifest_sha256")!=sha256(manifest):raise RuntimeError("回传验证与此归档 manifest 不匹配")
    r=load(a.rental)
    intent={"utc":utcnow(),"instance_id":r["instance_id"],"verified_copy_evidence":str(a.verified_copy),"execute":a.execute}
    dump(a.run_dir/"cost/release-intent.json",intent)
    if not a.execute:print("Release reviewed; --execute is still absent, no deletion performed.");raise SystemExit(0)
    if platform.system()!="Linux":raise SystemExit("只在目标服务器使用 provider 的实例级 Key 释放")
    require_authorization(a.authorization,"allow_destroy_poc_instance_after_verified_archive")
    if not (a.run_dir/"STOP_SUBMISSIONS").exists():raise RuntimeError("仍未停止提交")
    ok=destroy(r["instance_id"],a.run_dir/"cost/release.jsonl")
    print("Destroy request accepted; verify Instances/Storage and final billing from laptop." if ok else "Destroy unconfirmed; immediately verify from laptop.")
    raise SystemExit(0 if ok else 1)
