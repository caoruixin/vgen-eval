"""Check HTTP bytes before .mp4, ffprobe, and decode the entire A/V file."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

from common import ROOT, dump, sha256, utcnow


def binary(name):
    configured = os.environ.get(name.upper() + "_BIN")
    if configured:
        if not Path(configured).is_file():
            raise RuntimeError("不存在的媒体工具: " + configured)
        return configured
    found = shutil.which(name)
    if found:
        return found
    raise RuntimeError(name + " 未安装；完整媒体验证只在已授权的 GPU 服务器执行，不在笔记本安装工具")


def accept_mp4(status, content_type, first_bytes):
    content_type = content_type.split(";", 1)[0].strip().lower()
    if not 200 <= status < 300:
        raise ValueError(f"HTTP {status}，拒绝保存为 MP4")
    if content_type not in ("video/mp4", "application/mp4", "application/octet-stream"):
        raise ValueError("非视频内容类型: " + content_type)
    if len(first_bytes) < 12 or first_bytes[4:8] != b"ftyp":
        raise ValueError("MP4 ftyp 签名缺失，拒绝 JSON/HTML/损坏内容")


def fraction(value):
    try:
        a, b = str(value).split("/")
        return float(a)/float(b)
    except (ValueError, ZeroDivisionError):
        return None


def validate(path, evidence_dir, expected=None):
    path, evidence = Path(path), Path(evidence_dir)
    evidence.mkdir(parents=True, exist_ok=True)
    start = time.monotonic()
    probe_command = [binary("ffprobe"), "-v", "error", "-count_frames", "-show_format", "-show_streams", "-of", "json", str(path)]
    probe = subprocess.run(probe_command, capture_output=True, timeout=180)
    (evidence / "ffprobe.stderr.txt").write_bytes(probe.stderr)
    info = {}
    try:
        info = json.loads(probe.stdout) if probe.returncode == 0 else {}
    except json.JSONDecodeError:
        pass
    dump(evidence / "ffprobe.json", info)
    video = next((s for s in info.get("streams", []) if s.get("codec_type") == "video"), {})
    audio = next((s for s in info.get("streams", []) if s.get("codec_type") == "audio"), {})
    decode_command = [binary("ffmpeg"), "-nostdin", "-v", "error", "-xerror", "-i", str(path), "-map", "0:v", "-map", "0:a", "-f", "null", "-"]
    decode = subprocess.run(decode_command, capture_output=True, timeout=180)
    (evidence / "decode.stderr.txt").write_bytes(decode.stderr)
    n = video.get("nb_read_frames", video.get("nb_frames"))
    frames = int(n) if n and str(n).isdigit() else None
    seconds = float(info.get("format", {}).get("duration", 0) or 0)
    result = {"path": str(path), "sha256": sha256(path), "size_bytes": path.stat().st_size,
              "probe_exit_code": probe.returncode, "decode_exit_code": decode.returncode,
              "has_video": bool(video), "has_audio": bool(audio), "video_codec": video.get("codec_name"), "audio_codec": audio.get("codec_name"),
              "width": video.get("width"), "height": video.get("height"), "fps": fraction(video.get("avg_frame_rate")),
              "frames": frames, "duration_seconds": seconds, "video_duration_seconds": float(video.get("duration", 0) or 0),
              "audio_duration_seconds": float(audio.get("duration", 0) or 0), "audio_sample_rate": audio.get("sample_rate"), "audio_channels": audio.get("channels"),
              "technical_valid": probe.returncode == 0 and decode.returncode == 0 and bool(video) and bool(audio) and seconds > 0 and bool(frames),
              "validation_seconds": time.monotonic() - start, "validated_utc": utcnow(), "manual_av_sync": "pending", "spec_deviations": []}
    if expected:
        for key in ("width", "height", "fps"):
            if result[key] != expected.get(key):
                result["spec_deviations"].append({"field": key, "requested": expected.get(key), "actual": result[key]})
        # H3 nominal 5s can produce 124/24s. Preserve exact frame/duration, do not force it to 5.
        result["nominal_seconds_requested"] = expected.get("nominal_seconds")
    dump(evidence / "validation.json", result)
    return result


if __name__ == "__main__":
    p=argparse.ArgumentParser(); p.add_argument("video",type=Path); p.add_argument("--evidence",type=Path,required=True); a=p.parse_args()
    r=validate(a.video,a.evidence);print(json.dumps(r,ensure_ascii=False,indent=2));raise SystemExit(0 if r["technical_valid"] else 1)
