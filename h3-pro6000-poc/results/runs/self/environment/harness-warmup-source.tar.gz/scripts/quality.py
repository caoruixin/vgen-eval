"""Prepare blind A/B files and blank scores; never fabricate a review."""
import argparse
import csv
import html
import json
from pathlib import Path
import random
import secrets
import shutil

from common import ROOT, dump, load, sha256, utcnow


if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--self-run",type=Path,required=True);p.add_argument("--api-run",type=Path,required=True);p.add_argument("--out",type=Path,required=True);a=p.parse_args()
    if a.out.exists() and any(a.out.iterdir()):raise SystemExit("评分包已存在；避免改变用户已评顺序")
    a.out.mkdir(parents=True,exist_ok=True)
    cases=load(ROOT/"cases/cases.json")["cases"];rng=random.Random(secrets.randbits(128));mapping=[];scores=[];sections=[]
    for c in cases:
        matching=[]
        for source,provider in ((a.self_run,"self"),(a.api_run,"official_api")):
            candidates=[load(p) for p in (source/"records").glob("*.json")]
            rows=[r for r in candidates if r["case_id"]==c["id"] and r["provider"]==provider and r.get("media",{}).get("technical_valid") is True and (provider!="self" or r["phase"]=="baseline")]
            rows.sort(key=lambda r:r.get("seed") or 0)
            if not rows:break
            matching.append((source,rows[0]))
        if len(matching)!=2:continue
        if matching[0][1]["prompt_sha256"]!=matching[1][1]["prompt_sha256"] or matching[0][1].get("asset_sha256")!=matching[1][1].get("asset_sha256"):
            raise RuntimeError("业务提示词或素材哈希不同，不能配对: "+c["id"])
        rng.shuffle(matching)
        videos=[]
        for label,(source,row) in zip(("A","B"),matching):
            name=c["id"]+"-"+label+".mp4";shutil.copyfile(source/row["video_path"],a.out/name)
            mapping.append({"case_id":c["id"],"label":label,"provider":row["provider"],"request_id":row["request_id"],"video_sha256":sha256(a.out/name)})
            scores.append({"case_id":c["id"],"label":label,"reviewer":"","reviewed_utc":"","prompt_adherence_1to5":"","visual_motion_1to5":"","first_frame_retention_1to5":"NA" if c["task"]=="t2va" else "","audio_1to5":"","av_sync_1to5":"","deliverable_yes_no_unsure":"","defect_timestamps":"","notes":""})
            videos.append(f'<figure><figcaption>{label}</figcaption><video controls preload="metadata" src="{name}"></video></figure>')
        sections.append(f'<section><h2>{c["id"]} · {html.escape(c["title"])}</h2><p>{html.escape(c["prompt"])}</p><div class="pair">'+"".join(videos)+"</div><ul>"+"".join("<li>"+html.escape(s)+"</li>" for s in c["checklist"])+"</ul></section>")
    private=ROOT/"private"/(a.out.name+"-blind-key.json")
    dump(private,{"created_utc":utcnow(),"mapping":mapping},private=True)
    with (a.out/"scores.csv").open("w",newline="",encoding="utf-8-sig") as f:
        fields=list(scores[0]) if scores else ["case_id","label","reviewer","notes"]
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(scores)
    page='<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>MiniMax H3 匿名 A/B 评审</title><style>body{font:16px/1.7 system-ui;max-width:1200px;margin:40px auto;padding:0 20px;color:#203045}section{margin:40px 0;padding:24px;background:#f3f6fa}h1,h2{line-height:1.3}.pair{display:flex;gap:16px}figure{margin:0;width:50%}video{width:100%}figcaption{font-weight:bold}</style><h1>MiniMax H3 匿名 A/B 评审</h1><p>首位人工评审由用户担任。请完整观看并听音，再填写 scores.csv。每项 1–5 分；1 严重错误，3 需修复，5 可直接使用。可交付另填 yes/no/unsure。T2VA 首帧保持为 NA。请记录口型、台词、声画事件错配的时间戳。此处没有预填分数。</p>'+"".join(sections)+"</html>"
    (a.out/"review.html").write_text(page)
    print(json.dumps({"paired_cases":len(sections),"score_rows":len(scores),"quality_scores_filled":0,"blind_mapping":"stored separately under private/"},ensure_ascii=False))
