"""Download licensed stills, normalize framing, freeze prompts/matrix and hashes."""
from __future__ import annotations

import argparse
import hashlib
import html
import json
from pathlib import Path
import re
import urllib.request
import urllib.parse

from common import ROOT, digest, dump, load, sha256, utcnow


SOURCES = {
    "F01": ("File:Women Portrait Creative Commons.jpg", "crop", (.5, 0.0)),
    "F02": ("File:Perfume Bottle.jpg", "contain", (.5, .5)),
    "F03": ("File:A white cat walking towards the photographer.jpg", "contain", (.5, .5)),
    "F04": ("File:Lake Mountain Landscape.jpg", "crop", (.5, .5)),
}


def prepare():
    from PIL import Image, ImageOps, ImageDraw
    meta = load(ROOT / "research/upstream/commons-assets.json")
    by_title = {p["title"]: p["imageinfo"][0] for p in meta["query"]["pages"].values()}
    asset_dir = ROOT / "cases/assets"
    asset_dir.mkdir(parents=True, exist_ok=True)
    manifest = []
    old_path=ROOT/"cases/assets.lock.json"
    previous={x["case_id"]:x for x in load(old_path)["assets"]} if old_path.exists() else {}
    for case, (title, mode, centering) in SOURCES.items():
        info = by_title[title]
        ext = info["extmetadata"]
        license_name = ext["LicenseShortName"]["value"]
        if license_name not in ("CC0", "Public domain"):
            raise RuntimeError("需要重新审阅素材许可: " + title)
        original = asset_dir / (case + "-original.jpg")
        url = info["url"].split("?")[0]
        if not original.exists():
            with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "H3-PoC/1.0 (licensed still preparation)"}), timeout=60) as r:
                b = r.read(12 * 1024 * 1024)
            if len(b) != info["size"] or hashlib.sha1(b).hexdigest() != info["sha1"]:
                raise RuntimeError("Commons 原图大小/SHA1 不同")
            original.write_bytes(b)
        if hashlib.sha1(original.read_bytes()).hexdigest() != info["sha1"]:
            raise RuntimeError("原图已改变: " + str(original))
        im = ImageOps.exif_transpose(Image.open(original)).convert("RGB")
        if mode == "crop":
            frame = ImageOps.fit(im, (1344, 768), method=Image.Resampling.LANCZOS, centering=centering)
        else:
            # Preserve all of the bottle/cat; record padding so review can judge it.
            thumb = ImageOps.contain(im, (1344, 768), method=Image.Resampling.LANCZOS)
            background = im.resize((1, 1)).getpixel((0, 0))
            frame = Image.new("RGB", (1344, 768), background)
            frame.paste(thumb, ((1344 - thumb.width)//2, (768 - thumb.height)//2))
        path = asset_dir / (case + ".png")
        frame.save(path, optimize=True)
        manifest.append({"case_id": case, "file": str(path.relative_to(ROOT)), "sha256": sha256(path), "width": 1344, "height": 768,
                         "original_file": str(original.relative_to(ROOT)), "original_sha256": sha256(original), "commons_sha1": info["sha1"],
                         "title": title, "source_url": info["descriptionurl"], "download_url": url,
                         "author": html.unescape(re.sub("<[^>]+>", "", ext["Artist"]["value"])),
                         "license": license_name, "license_url": ext.get("LicenseUrl", {}).get("value", info["descriptionurl"]),
                         "normalization": {"mode": mode, "centering": centering, "output": [1344, 768]}, "observed_utc": utcnow()})
        if case in previous and previous[case]["sha256"]==manifest[-1]["sha256"]:
            manifest[-1]["observed_utc"]=previous[case]["observed_utc"]
    dump(ROOT / "cases/assets.lock.json", {"assets": manifest, "source_metadata_sha256": sha256(ROOT / "research/upstream/commons-assets.json")})
    contact = Image.new("RGB", (896, 560), "#eeeeee")
    draw = ImageDraw.Draw(contact)
    for i, a in enumerate(manifest):
        thumb = Image.open(ROOT / a["file"]).resize((448, 256))
        x, y = (i % 2)*448, (i//2)*280
        contact.paste(thumb, (x, y + 22))
        draw.text((x+8, y+4), a["case_id"] + " / " + a["license"], fill="black")
    contact.save(ROOT / "qa/firstframes-contact.png")
    lines = ["# 首帧素材许可与处理记录", "", "全部素材从 Wikimedia Commons 下载。保留原文件、许可元数据和 SHA256；规范化不使用收费生成。F01 人像只用于无台词转头，不声称本人背书。", ""]
    for a in manifest:
        lines += [f"- {a['case_id']}：[{a['title']}]({a['source_url']})；作者 {a['author']}；{a['license']}。", f"  原图 SHA256 `{a['original_sha256']}`；使用文件 SHA256 `{a['sha256']}`；处理 `{a['normalization']}`。"]
    (ROOT / "cases/LICENSES.md").write_text("\n".join(lines) + "\n")


def freeze():
    cases = load(ROOT / "cases/cases.json")["cases"]
    assets = {a["case_id"]: a for a in load(ROOT / "cases/assets.lock.json")["assets"]}
    matrix = []
    def add(c, phase, provider, seed, variant="bf16", batch=None):
        key = f"{phase}-{provider}-{variant}-{c['id']}-{seed if seed is not None else 'api'}"
        row = {"request_id": key, "case_id": c["id"], "task": c["task"], "phase": phase, "provider": provider,
               "variant": variant, "seed": seed, "prompt": c["prompt"], "prompt_sha256": hashlib.sha256(c["prompt"].encode()).hexdigest(),
               "asset_file": assets[c["id"]]["file"] if c["id"] in assets else None,
               "asset_sha256": assets[c["id"]]["sha256"] if c["id"] in assets else None, "batch": batch}
        matrix.append(row)
    for cid in ("T01", "F01"):
        c = next(c for c in cases if c["id"] == cid)
        for seed in (9001, 9002): add(c, "warmup", "self", seed)
    for c in cases:
        for seed in range(1101,1106) if c["task"] == "t2va" else range(2101,2104): add(c, "baseline", "self", seed)
        add(c, "comparison", "official_api", None, "official-H3")
    for c in [c for c in cases if c["id"] in ("T01", "T04", "T06", "F01", "F02", "F03")]:
        add(c, "turbo", "self", 1101 if c["task"] == "t2va" else 2101, "turbo8")
    for concurrency, ids in ((2,["T02","F04"]),(4,["T01","T03","F01","F03"])):
        for i, cid in enumerate(ids):
            c = next(c for c in cases if c["id"] == cid)
            add(c, f"concurrency_c{concurrency}", "self", 3101+i, batch=f"C{concurrency}")
    # Stability is time-bounded. Cycle cases and increment seed; not a promised sample count.
    payload = {"schema_version": 1, "frozen_utc": utcnow(), "cases_sha256": sha256(ROOT / "cases/cases.json"),
               "config_sha256": sha256(ROOT / "config/baseline.json"), "assets_manifest_sha256": sha256(ROOT / "cases/assets.lock.json"),
               "requests": matrix, "stability": {"duration_seconds":3600,"case_cycle":[c["id"] for c in cases],"seed_start":4101,"concurrency":1}}
    target = ROOT / "cases/matrix.lock.json"
    if target.exists():
        previous = load(target)
        if previous["cases_sha256"] == payload["cases_sha256"] and previous["config_sha256"] == payload["config_sha256"] and previous["assets_manifest_sha256"] == payload["assets_manifest_sha256"]:
            print("matrix unchanged", sha256(target)); return
        raise RuntimeError("已冻结清单不同；请先记录版本变更，不覆盖冻结清单")
    dump(target, payload)
    print(json.dumps({"matrix_sha256":sha256(target),"requests":len(matrix),"counts":{phase:sum(r["phase"]==phase for r in matrix) for phase in sorted({r["phase"] for r in matrix})}},ensure_ascii=False,indent=2))


if __name__ == "__main__":
    p=argparse.ArgumentParser(); p.add_argument("--download",action="store_true"); a=p.parse_args()
    if a.download: prepare()
    freeze()
