"""Server-only full validation of already downloaded official API outputs."""
import argparse
import platform
from pathlib import Path

from common import append, dump, load, utcnow
from media import validate
from run import export_csv


if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("run_dir",type=Path);a=p.parse_args()
    if platform.system()!="Linux":raise SystemExit("完整解码只在服务器执行")
    for path in sorted((a.run_dir/"records").glob("*.json")):
        r=load(path)
        if r["status"]!="downloaded_pending_server_validation":continue
        video=a.run_dir/r["video_path"]
        r["media"]=validate(video,a.run_dir/"outputs"/r["request_id"])
        r["status"]="validated" if r["media"]["technical_valid"] else "invalid_media"
        r["server_validation_utc"]=utcnow();dump(path,r)
        append(a.run_dir/"requests.jsonl",{"event":"server_media_validation",**r})
    export_csv(a.run_dir)
