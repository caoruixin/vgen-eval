"""Only selected pinned files. Execute only on the authorized rented Linux server."""
import argparse
import hashlib
import platform
from pathlib import Path
import time

from budget import Ledger
from common import ROOT, dump, load, require_authorization, sha256, utcnow


def verify(root, lock):
    verified=[]
    for f in lock["files"]:
        p=root/f["path"]
        if not p.is_file() or p.stat().st_size!=f["size"]:raise RuntimeError("文件缺失或大小不符: "+f["path"])
        actual=sha256(p)
        if f.get("sha256"):
            if actual!=f["sha256"]:raise RuntimeError("SHA256 不符: "+f["path"])
        elif f.get("git_blob_sha1"):
            h=hashlib.sha1(("blob "+str(p.stat().st_size)+"\0").encode());h.update(p.read_bytes())
            if h.hexdigest()!=f["git_blob_sha1"]:raise RuntimeError("Git blob SHA1 不符: "+f["path"])
        verified.append({"path":f["path"],"size":f["size"],"sha256":actual})
    return verified


if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--authorization",type=Path,default=ROOT/"private/authorization.json");p.add_argument("--ledger",type=Path,default=ROOT/"private/ledger.json");p.add_argument("--run-dir",type=Path,required=True);p.add_argument("--out",type=Path,required=True);p.add_argument("--turbo",action="store_true");p.add_argument("--verify-only",action="store_true");a=p.parse_args()
    if platform.system()!="Linux":raise SystemExit("权重与推理环境只在 8 卡服务器准备")
    require_authorization(a.authorization,"allow_gpu_rental")
    if not (a.run_dir/"HARDWARE_ACCEPTED.json").exists():raise SystemExit("先完成20分钟内的硬件/拓扑/通信验收")
    ledger=Ledger(a.ledger)
    if not ledger.snapshot()["open_rentals"]:raise SystemExit("缺少已登记的计费实例")
    ledger.guard(next_gpu_seconds=15*60)
    if not a.verify_only:
        reservations=[e for e in load(a.ledger)["entries"] if e["category"]=="storage_network" and "traffic_envelope" in e.get("source","") and e.get("actual_usd") is None]
        if not reservations:raise SystemExit("下载前必须先预留 traffic_envelope 流量费用（正常+可能替换）")
    cfg=load(ROOT/"config/baseline.json");start=time.monotonic();stamp=utcnow()
    if not a.verify_only:
        from huggingface_hub import snapshot_download,hf_hub_download
        if a.turbo:
            t=cfg["turbo"];hf_hub_download(t["repo"],t["filename"],revision=t["revision"],local_dir=str(Path(t["path"]).parent))
        else:
            snapshot_download(cfg["model_repo"],revision=cfg["model_revision"],allow_patterns=["FL2VA/**"],local_dir="/data/models/MiniMax-H3",max_workers=8)
    if a.turbo:
        t=cfg["turbo"];actual=sha256(t["path"])
        if actual!=t["sha256"]:raise RuntimeError("Turbo SHA256 不符")
        files=[{"path":t["path"],"sha256":actual}]
    else:files=verify(Path("/data/models/MiniMax-H3"),load(ROOT/"config/model-files.lock.json"))
    dump(a.out,{"started_utc":stamp,"finished_utc":utcnow(),"wall_seconds":time.monotonic()-start,"files":files,"turbo":a.turbo})
