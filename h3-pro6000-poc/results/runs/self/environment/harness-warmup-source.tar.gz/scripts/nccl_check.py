"""torchrun --standalone --nproc-per-node=8 scripts/nccl_check.py --out RUN/environment/nccl.json"""
import argparse
import datetime as dt
import os
from pathlib import Path
import time

from common import dump, utcnow


def main():
    p=argparse.ArgumentParser();p.add_argument("--out",type=Path,required=True);a=p.parse_args()
    import torch
    import torch.distributed as dist
    rank=int(os.environ["LOCAL_RANK"]);torch.cuda.set_device(rank)
    dist.init_process_group("nccl",timeout=dt.timedelta(seconds=75))
    n=dist.get_world_size()
    if n!=8:raise RuntimeError("通信验收必须 8 个进程")
    results={}
    for name in ("all_reduce","all_to_all_single"):
        x=torch.full((8*1024*1024,),float(rank+1),device="cuda",dtype=torch.float32)
        y=torch.empty_like(x)
        def op():
            if name=="all_reduce":
                y.copy_(x);dist.all_reduce(y)
            else:dist.all_to_all_single(y,x)
        for _ in range(3):op()
        torch.cuda.synchronize();dist.barrier();start=time.perf_counter()
        for _ in range(10):op()
        torch.cuda.synchronize();elapsed=(time.perf_counter()-start)/10
        if name=="all_reduce":correct=torch.all(y==sum(range(1,n+1))).item()
        else:correct=all(torch.all(chunk==i+1).item() for i,chunk in enumerate(y.chunk(n)))
        e=torch.tensor([elapsed,0 if correct else 1],device="cuda",dtype=torch.float64);dist.all_reduce(e,op=dist.ReduceOp.MAX)
        if e[1].item()!=0:raise RuntimeError(name+" correctness failed")
        results[name]={"bytes_per_rank":x.numel()*x.element_size(),"max_rank_mean_seconds":e[0].item(),
                       "payload_GB_per_second":(x.numel()*x.element_size()/1e9)/e[0].item(),"iterations":10,"correct":True}
    if rank==0:dump(a.out,{"utc":utcnow(),"world_size":n,"results":results,"note":"PyTorch/NCCL 小样；不能当作完整 nccl-tests 总线带宽或 H3 性能"})
    dist.destroy_process_group()


if __name__=="__main__":main()
