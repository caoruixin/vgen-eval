"""Confirm reviewed evidence before model download. No guessed GPU rank order."""
import argparse
from pathlib import Path
import platform
import time

from common import ROOT,dump,epoch,load,sha256,utcnow
from launch import command

if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--mapping",type=Path,required=True);p.add_argument("--rental",type=Path,required=True);p.add_argument("--run-dir",type=Path,required=True);a=p.parse_args()
    if platform.system()!="Linux":raise SystemExit("只在服务器确认硬件")
    m=load(a.mapping);r=load(a.rental);cfg=load(ROOT/"config/baseline.json");command(cfg,m)
    h=load(m["hardware_summary"]);n=load(m["nccl_result"]);alloc=load(m["instance_allocation_evidence"])
    if time.time()>epoch(r["started_utc"])+20*60:raise SystemExit("超过硬件验收20分钟边界，停止并释放")
    if not h["basic_checks_passed"] or h["topology_sha256"]!=m["topology_sha256"]:raise RuntimeError("硬件或拓扑证据不符")
    if n.get("world_size")!=8 or set(n.get("results",{}))!={"all_reduce","all_to_all_single"} or not all(v.get("correct") for v in n["results"].values()):raise RuntimeError("缺少8卡通信验收")
    if alloc.get("disk_GB")!=500 or alloc.get("image")!=cfg["image"] or str(alloc.get("instance_id"))!=str(r["instance_id"]):raise RuntimeError("租赁实例/磁盘/镜像证据不符")
    dump(a.run_dir/"HARDWARE_ACCEPTED.json",{"utc":utcnow(),"mapping_sha256":sha256(a.mapping),"instance_id":r["instance_id"],"basis":m["basis"]})
    print("Hardware review recorded; this does not establish H3 performance.")
