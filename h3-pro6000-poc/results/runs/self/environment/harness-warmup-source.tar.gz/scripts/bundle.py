"""Allowlist the server payload. Never copy .env, keys, private/, or old vgen data."""
import argparse
import json
from pathlib import Path
import tarfile

from common import ROOT, dump, sha256, utcnow
from run import verify_frozen


if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--output",type=Path,default=ROOT/"output/h3-server-payload.tar.gz");a=p.parse_args()
    verify_frozen()
    files=[]
    for directory in ("scripts","config","cases"):
        for path in (ROOT/directory).rglob("*"):
            if path.is_file() and "__pycache__" not in path.parts and not path.name.endswith("-original.jpg"):
                files.append(path)
    for name in ("README.md","RUNBOOK.md","PLAN.md"):
        path=ROOT/name
        if path.exists():files.append(path)
    for name in ("test_harness.py","server_media_checks.py","run_checks.py"):
        path=ROOT/"qa"/name
        if path.exists():files.append(path)
    for path in files:
        if path.is_symlink() or path.name.startswith(".env") or "private" in path.relative_to(ROOT).parts:raise RuntimeError("不允许打包: "+str(path))
    a.output.parent.mkdir(parents=True,exist_ok=True)
    with tarfile.open(a.output,"w:gz") as tf:
        for path in sorted(files):tf.add(path,arcname="h3-pro6000-poc/"+str(path.relative_to(ROOT)),recursive=False)
    manifest={"created_utc":utcnow(),"archive":str(a.output),"archive_sha256":sha256(a.output),"size_bytes":a.output.stat().st_size,
              "files":[{"path":str(p.relative_to(ROOT)),"sha256":sha256(p)} for p in sorted(files)],"secrets_included":False,"large_model_weights_included":False}
    dump(a.output.with_suffix(".manifest.json"),manifest)
    print(json.dumps({k:v for k,v in manifest.items() if k!="files"},ensure_ascii=False,indent=2))
