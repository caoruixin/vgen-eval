"""One rental wall-clock is charged once, including concurrent requests."""
from __future__ import annotations

import argparse
import time
import uuid
from pathlib import Path

from common import ROOT, dump, epoch, file_lock, load, require_authorization, utcnow


class BudgetError(RuntimeError):
    pass


class Ledger:
    def __init__(self, path):
        self.path = Path(path)

    def init(self):
        with file_lock(str(self.path) + ".lock"):
            if not self.path.exists():
                dump(self.path, {"schema_version": 1, "created_utc": utcnow(), "entries": [], "rentals": [], "release_evidence": []})

    def _snapshot(self, d, now=None):
        now = time.time() if now is None else now
        totals = {"gpu": 0.0, "storage_network": 0.0, "api": 0.0}
        hours = 0.0
        for x in d["entries"]:
            totals[x["category"]] += x["actual_usd"] if x.get("actual_usd") is not None else x["reserved_usd"]
        for r in d["rentals"]:
            h = max(0, (epoch(r["ended_utc"]) if r.get("ended_utc") else now) - epoch(r["started_utc"])) / 3600
            hours += h
            totals["gpu"] += r.get("settled_gpu_usd") if r.get("settled_gpu_usd") is not None else h * r["gpu_hour_usd"]
            totals["storage_network"] += r.get("settled_disk_usd") if r.get("settled_disk_usd") is not None else h * r["disk_hour_usd"]
        return {"categories_usd": totals, "total_usd": sum(totals.values()), "gpu_hours": hours,
                "open_rentals": [r for r in d["rentals"] if not r.get("ended_utc")],
                "pending": [e for e in d["entries"] if e.get("actual_usd") is None], "asof_utc": utcnow()}

    def snapshot(self):
        self.init()
        with file_lock(str(self.path) + ".lock"):
            return self._snapshot(load(self.path))

    def _guard(self, d, next_gpu_seconds=0, next_api_usd=0, next_other_usd=0, reserve_archive=True, now=None):
        s = self._snapshot(d, now)
        limits = load(ROOT / "config/baseline.json")["limits"]
        active = s["open_rentals"]
        if len(active) > 1:
            raise BudgetError("只允许一个付费 GPU 实例处于开启状态")
        gpu_rate = sum(r["gpu_hour_usd"] for r in active)
        disk_rate = sum(r["disk_hour_usd"] for r in active)
        reserve_s = limits["archive_release_minutes"] * 60 if reserve_archive and active else 0
        projected_hours = s["gpu_hours"] + (next_gpu_seconds + reserve_s) / 3600
        totals = dict(s["categories_usd"])
        totals["gpu"] += gpu_rate * (next_gpu_seconds + reserve_s) / 3600
        totals["storage_network"] += next_other_usd + disk_rate * (next_gpu_seconds + reserve_s) / 3600
        totals["api"] += next_api_usd
        for cat, cap in (("gpu", "gpu_usd"), ("storage_network", "storage_network_usd"), ("api", "api_usd")):
            if totals[cat] > limits[cap] + 1e-9:
                raise BudgetError(f"{cat} 最坏预留 ${totals[cat]:.4f} 超过 ${limits[cap]}")
        if sum(totals.values()) > limits["total_usd"] + 1e-9 or projected_hours > limits["gpu_hours"] + 1e-9:
            raise BudgetError("总预算或累计 8 小时边界将被触及")
        for r in active:
            if (time.time() if now is None else now) > epoch(r["hard_release_utc"]):
                raise BudgetError("已到实例硬释放时间")
        return {**s, "projected_with_archive_usd": totals, "projected_gpu_hours": projected_hours}

    def guard(self, **kwargs):
        self.init()
        with file_lock(str(self.path) + ".lock"):
            return self._guard(load(self.path), **kwargs)

    def reserve(self, category, amount, source, request_id=None):
        if category not in ("gpu", "storage_network", "api") or amount < 0:
            raise BudgetError("非法预留")
        self.init()
        with file_lock(str(self.path) + ".lock"):
            d = load(self.path)
            if category == "gpu":
                raise BudgetError("GPU 只能按租赁计费窗口记录，防止并发双计")
            self._guard(d, next_api_usd=amount if category == "api" else 0, next_other_usd=amount if category == "storage_network" else 0)
            eid = str(uuid.uuid4())
            d["entries"].append({"id": eid, "category": category, "reserved_usd": amount, "actual_usd": None,
                                 "source": source, "request_id": request_id, "created_utc": utcnow()})
            dump(self.path, d)
            return eid

    def settle(self, eid, amount, source):
        if amount < 0:
            raise BudgetError("结算不能为负")
        with file_lock(str(self.path) + ".lock"):
            d = load(self.path)
            entry = next(x for x in d["entries"] if x["id"] == eid)
            entry.update(actual_usd=amount, settled_source=source, settled_utc=utcnow())
            dump(self.path, d)

    def register_rental(self, rental, authorization):
        require_authorization(authorization, "allow_gpu_rental")
        self.init()
        with file_lock(str(self.path) + ".lock"):
            d = load(self.path)
            if any(not r.get("ended_utc") for r in d["rentals"]):
                raise BudgetError("上一个实例尚未确认释放")
            if len(d["rentals"]) >= 2:
                raise BudgetError("最多替换一次")
            if not 0 < rental["gpu_hour_usd"] <= 15 or rental["disk_hour_usd"] < 0:
                raise BudgetError("单价非法或 GPU 超过 $15/h")
            epoch(rental["started_utc"])
            epoch(rental["hard_release_utc"])
            d["rentals"].append(rental)
            self._guard(d, next_gpu_seconds=20 * 60)
            dump(self.path, d)

    def close_rental(self, instance_id, evidence_path, ended_utc):
        if not Path(evidence_path).is_file():
            raise BudgetError("缺少释放证据文件")
        with file_lock(str(self.path) + ".lock"):
            d = load(self.path)
            r = next(x for x in d["rentals"] if str(x["instance_id"]) == str(instance_id))
            r["ended_utc"] = ended_utc
            d["release_evidence"].append({"instance_id": instance_id, "path": str(evidence_path), "recorded_utc": utcnow()})
            dump(self.path, d)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("command", choices=["init", "status", "check", "reserve", "settle", "register", "close"])
    p.add_argument("--ledger", type=Path, default=ROOT / "private/ledger.json")
    p.add_argument("--authorization", type=Path, default=ROOT / "private/authorization.json")
    p.add_argument("--json", type=Path)
    p.add_argument("--category", choices=["api", "storage_network"])
    p.add_argument("--usd", type=float, default=0)
    p.add_argument("--id")
    p.add_argument("--source")
    p.add_argument("--next-gpu-seconds", type=int, default=0)
    p.add_argument("--ended-utc")
    a = p.parse_args()
    ledger = Ledger(a.ledger)
    ledger.init()
    if a.command == "check":
        result = ledger.guard(next_gpu_seconds=a.next_gpu_seconds, next_api_usd=a.usd if a.category == "api" else 0, next_other_usd=a.usd if a.category == "storage_network" else 0)
    elif a.command == "reserve":
        result = {"reservation_id": ledger.reserve(a.category, a.usd, a.source)}
    elif a.command == "settle":
        ledger.settle(a.id, a.usd, a.source)
        result = ledger.snapshot()
    elif a.command == "register":
        ledger.register_rental(load(a.json), a.authorization)
        result = ledger.snapshot()
    elif a.command == "close":
        ledger.close_rental(a.id, a.json, a.ended_utc)
        result = ledger.snapshot()
    else:
        result = ledger.snapshot()
    import json
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
