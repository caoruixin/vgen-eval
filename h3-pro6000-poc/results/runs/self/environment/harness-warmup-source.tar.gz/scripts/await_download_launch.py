"""Server coordinator: wait for verified pinned download, then launch baseline."""
import os,platform,subprocess,time
from pathlib import Path
from common import ROOT,load,utcnow,append
if platform.system()!='Linux':raise SystemExit('Server only')
r=ROOT/'runs/self';deadline=time.time()+65*60
while not (r/'environment/model-files-verified.json').exists():
    if time.time()>deadline or (r/'STOP_SUBMISSIONS').exists():raise SystemExit('Download wait stopped')
    time.sleep(5)
append(r/'deploy/stages.jsonl',{'event':'weights_verified_start_bf16','utc':utcnow()})
subprocess.run(['python3','scripts/server_dispatch.py','--name','server-bf16','--log','runs/self/deploy/server-bf16.log','--','python3','scripts/launch.py','--execute','--mapping','private/topology-mapping.json','--out','runs/self/deploy/bf16'],cwd=ROOT,check=True)
