"""Exact pinned vLLM-Omni and current official MiniMax V2 wire contracts."""
from __future__ import annotations

import base64
import json
import socket
import time
import urllib.error
import urllib.request
from urllib.parse import quote, urlsplit
import uuid
from pathlib import Path

from common import ROOT, append, canonical, redact, sha256, utcnow
from media import accept_mp4


class ProviderError(RuntimeError):
    def __init__(self, message, ambiguous=False, http_status=None):
        super().__init__(message)
        self.ambiguous = ambiguous
        self.http_status = http_status


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None  # Never forward Authorization or a POST to another destination.


def multipart(fields, asset=None):
    boundary = "h3poc-" + uuid.uuid4().hex
    parts = []
    for key, value in fields.items():
        parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{key}"\r\n\r\n{value}\r\n'.encode())
    if asset:
        path = Path(asset)
        parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="input_reference"; filename="{path.name}"\r\nContent-Type: image/png\r\n\r\n'.encode() + path.read_bytes() + b"\r\n")
    parts.append(f"--{boundary}--\r\n".encode())
    return b"".join(parts), "multipart/form-data; boundary=" + boundary


def vllm_fields(case, cfg):
    turbo = cfg["turbo"] if case["variant"] == "turbo8" else None
    active = turbo or cfg
    fields = {"prompt": case["prompt"], "width": cfg["width"], "height": cfg["height"], "fps": cfg["fps"],
              "num_inference_steps": active["num_inference_steps"], "flow_shift": active["flow_shift"], "seed": case["seed"],
              "aspect_ratio":"adaptive" if case["task"]=="fl2va" else "16:9", "short_edge":cfg["height"],
              "return_stage_metrics":"true",
              "extra_params": json.dumps({"task": case["task"], "duration": float(cfg["nominal_seconds"]), "audio_flow_shift": active["audio_flow_shift"]})}
    if turbo:
        fields["lora"] = json.dumps({"name":"h3-turbo-8step-v1.0", "path":turbo["path"], "scale":turbo["scale"]})
    return fields


def minimax_payload(case, cfg):
    content = [{"type": "text", "text": case["prompt"]}]
    if case.get("asset_file"):
        path = ROOT / case["asset_file"]
        if sha256(path) != case["asset_sha256"]:
            raise RuntimeError("首帧 SHA256 不符")
        content.append({"type":"image_url", "role":"first_frame", "image_url":{"url":"data:image/png;base64," + base64.b64encode(path.read_bytes()).decode()}})
    return {"model":"MiniMax-H3", "resolution":"768P", "duration":5,
            "ratio":"adaptive" if case.get("asset_file") else "16:9", "content":content}


class Client:
    def __init__(self, provider, base_url, cfg, log, api_key=None, allow_mock=False, poll_seconds=None):
        self.provider, self.base, self.cfg, self.log = provider, base_url.rstrip("/"), cfg, Path(log)
        self.poll = cfg["poll_seconds"] if poll_seconds is None else poll_seconds
        self.api_key = api_key
        host = urlsplit(base_url).hostname
        if provider == "official_api" and self.base != "https://api.minimax.io" and not (allow_mock and host in ("127.0.0.1", "localhost")):
            raise RuntimeError("API 必须使用官方国际站")
        if provider == "self" and host not in ("127.0.0.1", "localhost"):
            raise RuntimeError("自建服务只通过本机或 SSH 回环隧道访问")
        self.opener = urllib.request.build_opener(NoRedirect())

    def scrub(self,value):
        if isinstance(value,dict):return {k:self.scrub(v) for k,v in value.items()}
        if isinstance(value,list):return [self.scrub(v) for v in value]
        if isinstance(value,str) and self.api_key:return value.replace(self.api_key,"[REDACTED]")
        return value

    def headers(self):
        return {"Authorization":"Bearer " + self.api_key} if self.provider == "official_api" and self.api_key else {}

    def json_request(self, method, path, body=None, content_type="application/json", timeout=30):
        url = self.base + path
        start = time.monotonic()
        try:
            request = urllib.request.Request(url, data=body, method=method, headers={**self.headers(), **({"Content-Type":content_type} if body is not None else {})})
            with self.opener.open(request, timeout=timeout) as r:
                raw = r.read(8*1024*1024)
                if "application/json" not in r.headers.get("Content-Type", "").lower():
                    raise ProviderError("JSON 接口返回非 JSON Content-Type", ambiguous=method == "POST")
                result = self.scrub(json.loads(raw))
                append(self.log,{"event":"http_response","method":method,"path":path,"utc":utcnow(),"http_status":r.status,"seconds":time.monotonic()-start,"response":result})
                return result
        except urllib.error.HTTPError as e:
            raw = self.scrub(e.read(16384).decode("utf-8", errors="replace"))
            e.close()
            append(self.log,{"event":"http_error","method":method,"path":path,"utc":utcnow(),"http_status":e.code,"body":raw})
            # 5xx after POST may have created a job; do not auto-retry it.
            raise ProviderError(f"HTTP {e.code}: {redact(raw)[:500]}", ambiguous=method == "POST" and e.code >= 500, http_status=e.code) from None
        except (OSError, ValueError, urllib.error.URLError) as e:
            append(self.log,{"event":"transport_or_parse_error","method":method,"path":path,"utc":utcnow(),"exception_type":type(e).__name__})
            raise ProviderError(type(e).__name__, ambiguous=method == "POST") from None

    def submit(self, case):
        if self.provider == "official_api":
            payload = minimax_payload(case, self.cfg)
            response = self.json_request("POST", "/v2/video_generation", canonical(payload), timeout=60)
            task_id = response.get("task_id")
        else:
            asset = ROOT / case["asset_file"] if case.get("asset_file") else None
            body, content_type = multipart(vllm_fields(case,self.cfg), asset)
            response = self.json_request("POST", "/v1/videos", body, content_type, timeout=60)
            task_id = response.get("id")
        if not task_id:
            raise ProviderError("创建响应缺少 task_id/id，需要核实任务；禁止盲目重提", ambiguous=True)
        return str(task_id), response

    def query(self, task_id):
        task_id = quote(task_id, safe="")
        path = "/v2/query/video_generation/" + task_id if self.provider == "official_api" else "/v1/videos/" + task_id
        response = self.json_request("GET", path)
        task = response.get("task", {}) if self.provider == "official_api" else response
        if not task.get("status"):
            raise ProviderError("查询响应缺少 status")
        return task, response

    def download(self, task_id, task, destination, timeout=120):
        path = Path(destination)
        path.parent.mkdir(parents=True,exist_ok=True)
        if self.provider == "official_api":
            url = task.get("content", {}).get("url")
            if not url:
                raise ProviderError("任务成功但无 content.url")
            if urlsplit(url).scheme != "https" and urlsplit(url).hostname not in ("127.0.0.1", "localhost"):
                raise ProviderError("下载 URL 非 HTTPS")
        else:
            url = self.base + "/v1/videos/" + quote(task_id, safe="") + "/content"
        # Deliberately use a separate opener with no MiniMax authentication headers.
        request = urllib.request.Request(url, headers={"User-Agent":"H3-PoC-download/1.0"})
        tmp = path.with_suffix(".part")
        start = time.monotonic()
        try:
            with urllib.request.urlopen(request,timeout=timeout) as r:
                initial = r.read(65536)
                accept_mp4(r.status, r.headers.get("Content-Type",""), initial)
                ctype = r.headers.get("Content-Type", "")
                expected_length = int(r.headers["Content-Length"]) if r.headers.get("Content-Length") else None
                total = len(initial)
                with tmp.open("wb") as f:
                    f.write(initial)
                    while True:
                        if time.monotonic() - start > timeout:
                            raise TimeoutError("下载总时间超时")
                        b=r.read(1024*1024)
                        if not b: break
                        total += len(b)
                        if total > 1024*1024*1024:
                            raise ProviderError("单条文件超过 1GiB，停止下载")
                        f.write(b)
                if expected_length is not None and total != expected_length:
                    raise ProviderError(f"文件长度不完整: expected={expected_length}, received={total}")
                tmp.replace(path)
                return {"http_status":r.status,"content_type":ctype,"download_seconds":time.monotonic()-start,"bytes":total,"expected_content_length":expected_length}
        except (OSError, ValueError, urllib.error.URLError) as e:
            raise ProviderError("下载失败: " + type(e).__name__) from None

    def list_recent(self):
        path = "/v2/query/video_generation?page_num=1&page_size=20&filter.model=MiniMax-H3" if self.provider == "official_api" else "/v1/videos"
        return self.json_request("GET",path)

    def sync(self, case, destination):
        if self.provider != "self":
            raise RuntimeError("官方 API 只能异步提交")
        asset = ROOT / case["asset_file"] if case.get("asset_file") else None
        body, ctype = multipart(vllm_fields(case,self.cfg), asset)
        req=urllib.request.Request(self.base+"/v1/videos/sync",data=body,headers={"Content-Type":ctype},method="POST")
        path=Path(destination);path.parent.mkdir(parents=True,exist_ok=True)
        tmp=path.with_suffix(".part")
        start=time.monotonic()
        try:
            with self.opener.open(req,timeout=self.cfg["request_timeout_seconds"]) as r:
                initial=r.read(65536)
                accept_mp4(r.status,r.headers.get("Content-Type",""),initial)
                total=len(initial)
                with tmp.open("wb") as f:
                    f.write(initial)
                    while True:
                        b=r.read(1024*1024)
                        if not b:break
                        total+=len(b)
                        if total>1024*1024*1024:raise ProviderError("单文件超过 1GiB")
                        f.write(b)
                tmp.replace(path)
                metadata={"task_id":r.headers.get("X-Request-Id"),"http_status":r.status,"content_type":r.headers.get("Content-Type"),
                          "inference_time_s":r.headers.get("X-Inference-Time-S"),"peak_memory_mb":r.headers.get("X-Peak-Memory-MB"),
                          "stage_durations":json.loads(r.headers.get("X-Stage-Durations","null")),"bytes":total,
                          "sync_response_seconds":time.monotonic()-start}
                append(self.log,{"event":"sync_media_response","utc":utcnow(),**metadata})
                return metadata
        except urllib.error.HTTPError as e:
            raw=self.scrub(e.read(16384).decode("utf-8",errors="replace"));e.close()
            append(self.log,{"event":"sync_http_error","utc":utcnow(),"http_status":e.code,"body":raw})
            raise ProviderError(f"同步 HTTP {e.code}: {redact(raw)[:500]}",ambiguous=e.code>=500,http_status=e.code) from None
        except (OSError, ValueError, urllib.error.URLError) as e:
            raise ProviderError("同步 POST/视频失败: "+type(e).__name__,ambiguous=True) from None
