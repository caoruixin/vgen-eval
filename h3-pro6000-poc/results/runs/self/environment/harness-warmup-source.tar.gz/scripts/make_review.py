"""Render the current read-only quote snapshot into the Chinese execution review."""
import datetime as dt
import json
from pathlib import Path
from zoneinfo import ZoneInfo

from common import ROOT,dump,load,sha256,utcnow


if __name__=="__main__":
    data=load(ROOT/"research/upstream/offer-review.json")
    q=load(ROOT/"qa/dry-run-summary.json")
    observed=dt.datetime.fromisoformat(data["observed_utc"]).astimezone(ZoneInfo("America/Los_Angeles"))
    offers=data["offers"]
    primary=next((o for o in offers if o["offer_id"]==58438815 and not o["cautions"]),next((o for o in offers if o["region"]=="Texas, US" and not o["cautions"]),None))
    label=f"Texas offer {primary['offer_id']}" if primary else "本次没有合格Texas现货，等待或重新筛选"
    lines=["# MiniMax H3 8卡PRO6000：收费执行前审阅单", "",
           f"库存观察时间：**{observed:%Y-%m-%d %H:%M:%S %Z}**（`{data['observed_utc']}`）。该快照不保留库存，下单前再次查询并核对结账价。", "",
           "当前仍未租机、未提交官方视频生成、未进行H3推理。本轮GPU/API/磁盘流量已发生费用为$0，累计GPU计费0小时。预算和范围的共识不等于已经选择租机控制方式。", "",
           "## 已经准备并检查", "",
           "- 完整环境只装在租用的8×PRO6000服务器；笔记本不装H3/CUDA/vLLM、不下载权重、不创建H3虚拟环境。", 
           f"- 10个场景的准确提示词和检查清单、4个开放许可首帧及SHA256、68条固定请求已冻结。冻结矩阵SHA256：`{q['matrix_sha256']}`。", 
           "- Python标准库离线检查通过：授权缺失阻断、任务ID先落盘、超时不自动重提、相同请求竞争不重复创建、分项预算锁、并发窗口不双计、JSON错误拒存MP4等。具体测试日志在qa/unit-tests.txt。",
           "- 独立阶段：预热4，BF16基线30T2VA+12FL2VA，官方API10，C2/C4共6，可选Turbo6；稳定性另按60分钟运行。", 
           "- 模型匿名访问成功：固定revision的FL2VA共有81个文件、144,051,182,625字节。仅拉元数据和model_index，没有下载大权重。", 
           "- 官方镜像amd64摘要与既定值一致，压缩层9,954,971,979字节；镜像配置CUDA13.0.2，无默认Entrypoint/Cmd。计划用Vast SSH模式注入，不在Vast容器内二次Docker或现场编译框架。", 
           "- 配方与运行代码的Turbo 8/9冲突已定位：该固定commit的校验器和上游测试要求请求8，9是sigma点数且会被拒绝。服务器先跑runtime_contract.py验证，不把文档当作实测。", "",
           "仍未完成：真实GPU/驱动/拓扑/P2P/NCCL验收、SSH实际启动、H3生成与性能、官方Key认证/余额、服务器ffprobe和全解码、人工音画质量。最终Word/Markdown实测报告必须等真实执行与人工复核后生成。", "",
           "## 当前候选与全部已知计价", "",
           "全部为单机8×RTX PRO6000 Server、每卡列表96GB，Verified。最大可用磁盘列不代表已分配量；本报价计算的是创建时**500GB**。GPU实物和MIG仍须登录验收。", "",
           "| offer / 地区 | GPU $/h | 500GB磁盘 $/h | 合计 $/h，流量另计 | 下载 / 上传 $/GB | RAM列表MiB | 可靠度 | 下载Mbps | 最大可用磁盘GB | 最长剩余租期 |",
           "| --- | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: | --- |"]
    for o in offers:
        days=o["maximum_duration_seconds"]/86400
        lines.append(f"| {o['offer_id']} / {o['region']} | {o['gpu_hour_usd']:.6f} | {o['disk_hour_usd']:.6f} | {o['total_hour_before_traffic_usd']:.6f} | {o['download_GB_usd']:.8f} / {o['upload_GB_usd']:.8f} | {o['cpu_ram_MiB']:,} | {o['reliability']*100:.3f}% | {o['download_Mbps']:.1f} | {o['max_disk_listing_GB']:.1f} | 约{days:.2f}天 |")
    candidate_notes=f"建议优先：**{label}**，同类Texas可替换。"
    if any(o['offer_id']==49181770 and not o['cautions'] for o in offers):candidate_notes+="新的California 49181770是另一台主机，并非旧的48441828；本次网络更快、RAM更大、可靠度超过99%，可作备选。"
    if any(o['offer_id']==58529276 for o in offers):candidate_notes+="Bulgaria本次磁盘/DLPerf已变化，不沿用旧差分数，但流量单价较高。"
    if any(o['region']=='Czechia, CZ' and o['gpu_hour_usd']>15 for o in offers):candidate_notes+="表中的Czechia GPU单价超$15/h，不选。"
    lines += ["",candidate_notes, "",
              "历史可靠度和DLPerf只筛选，不是SLA或H3性能；不根据DLPerf预测生成速度。原始完整JSON保存在research/upstream/vast-offers.json及offer-review.json。", "",
              "## 预计消耗与预算", "",
              "| offer | 6小时40分、180GB入站+20GB出站、10条API的估算 | 8小时、330GB入站+20GB出站、10条API的情景估算 |", "| --- | ---: | ---: |"]
    for o in offers:
        lines.append(f"| {o['offer_id']} | ${o['6h40m_estimate_usd']:.2f} | ${o['8h_10api_330GBin_20GBout_usd']:.2f} |")
    if primary:
        gpu=primary["gpu_hour_usd"]*8;disk=primary["disk_hour_usd"]*8;traffic=330*primary["download_GB_usd"]+20*primary["upload_GB_usd"]
        lines += ["",f"以首选{primary['offer_id']}的8小时情景分解：GPU **${gpu:.2f}** + 磁盘 **${disk:.2f}** + 流量 **${traffic:.2f}** + 10条API标价 **$4.00** = **${gpu+disk+traffic+4:.2f}**。这不是已支付金额，也不是含一切未知附加费的结账承诺。"]
    lines += ["", "API价格已重新核对：MiniMax-H3 768P输出$0.08/秒，名义5秒约$0.40，10条约$4；每任务前5张输入图免费，本次每个FL2VA只有1张。真实秒数/扣费读取usage和账户账单。每条先保守预留$1，结算前不把预留额冒充实际支出。", "",
              "总预算硬上限仍为$150（GPU$120、磁盘流量$20、API$10），累计GPU最多8小时。下载、镜像拉取、失败、替换、等待和归档都在计费时钟内，不能另加8小时推理。归档/释放至少预留25分钟，建议硬释放时间比累计8小时提前5分钟。", "",
              "尚不确定：下单时库存、实际税费/支付渠道或充值附加费、账户优惠、最低充值档位、是否有单独最低租期。官方说明on-demand按秒计费，但这些结账项仍须核对；任何一项使总额或分项边界将被突破，停止下单/提交，不自动加价。当前控制台余额为$0（本轮浏览器已读观察），需有可用余额后才租赁；充值本金与已消耗费用分开记。", "",
              "## 需要用户选择的控制方式", "",
              "**A：我操作已登录的Vast网页租机，SSH全程执行（建议）。** 你处理必要的充值/敏感信息输入；我按审阅报价创建固定镜像+500GB、优先使用已有SSH密钥，接管验收、部署、实测、增量回传和核验后的释放。无需在笔记本安装Vast CLI或H3环境，也不需要把账户API Key发到聊天。", "",
              "**B：你按此单下单并提供SSH连接信息，我接管服务器执行。** 镜像摘要、SSH模式、500GB和onstart按RUNBOOK配置。我部署、测试、回传；释放方式在此次控制授权中一并明确，使用本实例凭据或你操作控制台完成并提供终态证据。", "",
              "选择时请一并明确授权：先完成1条官方API样例，验证账户后租用所选候选，在GPU≤$120/磁盘流量≤$20/API≤$10/总≤$150/累计≤8小时内执行，允许归档验证后的正常释放，以及20分钟硬件不通过、累计2小时无有效自建视频、不可恢复错误或预算/时间边界的止损释放。最多替换一次，不自动加价、扩范围或留收费存储。此授权将记录原话，之后在范围内持续执行，不逐步反复确认。", "",
              "本次之所以停在这个选择，是用户明确要求先完成免费准备和具体offer审阅、之后再选租机控制方式；不是地域/预算/目标需要重问。当前没有据方案附件或交接提示推定收费授权。", "",
              "## 证据与限制", "",
              "- README.md / RUNBOOK.md：服务器环境边界与具体命令；config/和cases/：固定配置/文件/种子；output/：不含密钥或权重的服务器payload与SHA256。", 
              "- qa/dry-run-summary.json / unit-tests.txt：离线检查；GPU及完整媒体QA明确仍未执行。模板授权默认为false，已有收费账本为0。", 
              "- research/credential-incident.md：一次测试工具日志凭据暴露及清理记录。已有工具消息无法撤回，建议收费执行前轮换Key；交付产物不含该值，.env未改动。", 
              "- 最终性能/成功率/可交付率/成本结论当前均不存在；不会填预测或外部PRO5000数字。", "",
              "官方来源：[Vast筛选页](https://cloud.vast.ai/?gpu_option=RTX+PRO+6000+S&gpuModelNames=rtxPro6000BlackwellServer&offerGpuNumMax=8&offerGpuNumMin=8&instanceDiskSizeMin=500)、[Vast计价](https://docs.vast.ai/guides/instances/pricing)、[Vast SSH/入口](https://docs.vast.ai/guides/instances/docker-environment)、[MiniMax定价](https://platform.minimax.io/docs/pricing/overview)、[创建](https://platform.minimax.io/docs/api-reference/video-generation-v2-create)、[查询](https://platform.minimax.io/docs/api-reference/video-generation-v2-query)、[固定源码Turbo测试](https://github.com/vllm-project/vllm-omni/blob/5917730a4b02aedb44d374173cdc1b10484ccd52/tests/diffusion/models/minimax_h3/test_minimax_h3_turbo_matrix.py)、[NVIDIA兼容性](https://docs.nvidia.com/deploy/cuda-compatibility/minor-version-compatibility.html)。", ""]
    (ROOT/"EXECUTION_REVIEW.md").write_text("\n".join(lines))
    dump(ROOT/"STATUS.json",{"updated_utc":utcnow(),"phase":"awaiting_user_control_choice_and_paid_execution_authorization","gpu_rentals":0,"official_generation_requests":0,"real_h3_videos":0,"gpu_billed_hours":0,"spent_gpu_usd":0,"spent_api_usd":0,"spent_storage_network_usd":0,
         "local_h3_environment_installed":False,"matrix_sha256":q["matrix_sha256"],"quote_observed_utc":data["observed_utc"],"suggested_offer_id":primary["offer_id"] if primary else None,
         "control_method_selected":None,"authorization_record_exists":(ROOT/"private/authorization.json").exists(),"full_decode_status":"pending_server","word_report_status":"pending_real_measurements_and_user_review","credential_rotation":"recommended_after_tool_log_exposure; not confirmed"})
    print("Execution review and zero-spend status saved; no paid action performed.")
