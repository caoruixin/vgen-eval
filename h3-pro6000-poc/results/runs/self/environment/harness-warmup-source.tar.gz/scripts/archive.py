"""Manifest and verify copied evidence before normal instance destruction."""
import argparse
import hashlib
from pathlib import Path

from common import dump,load,sha256,utcnow


if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("action",choices=["manifest","verify"]);p.add_argument("--run-dir",type=Path,required=True);a=p.parse_args()
    target=a.run_dir/"cost/archive-manifest.json"
    if a.action=="manifest":
        if not (a.run_dir/"STOP_SUBMISSIONS").exists():raise SystemExit("先停止提交，等当前任务/遥测落盘，再归档")
        files=[]
        for p0 in sorted(a.run_dir.rglob("*")):
            if not p0.is_file() or p0==target or p0.name.endswith(".lock") or p0.name=="archive-verified.json":continue
            if p0.is_symlink() or p0.name.startswith(".env"):raise RuntimeError("归档路径含不允许的链接/凭据文件")
            files.append({"path":str(p0.relative_to(a.run_dir)),"size":p0.stat().st_size,"sha256":sha256(p0)})
        dump(target,{"created_utc":utcnow(),"files":files})
        print("Manifest created:",len(files),"files. Copy directory to laptop, then run verify there.")
    else:
        data=load(target);failed=[]
        for f in data["files"]:
            rel=Path(f["path"])
            if rel.is_absolute() or ".." in rel.parts:raise RuntimeError("非法 manifest 相对路径")
            p0=a.run_dir/rel
            if not p0.is_file() or p0.stat().st_size!=f["size"] or sha256(p0)!=f["sha256"]:failed.append(f["path"])
        dump(a.run_dir/"cost/archive-verified.json",{"verified_utc":utcnow(),"manifest_sha256":sha256(target),"files":len(data["files"]),"passed":not failed,"failed":failed})
        if failed:raise SystemExit("回传校验失败: "+str(failed))
        print("Archive verified:",len(data["files"]),"files. This does not mean the instance has been destroyed.")
