#!/usr/bin/env bash
# Only a Vast onstart hook, after explicit rental authorization. No local execution.
set -euo pipefail
test "$(uname -s)" = Linux
umask 077
mkdir -p /data/h3-control /data/models /data/h3-video-store
# Vast's SSH mode may not forward these values into interactive sessions.
# Keep only this container's provider credential, outside any evidence/package tree.
python3 - <<'PY'
import json,os,pathlib
p=pathlib.Path('/data/h3-control/instance-auth.json')
data={n:os.environ.get(n) for n in ('CONTAINER_ID','CONTAINER_API_KEY')}
fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
os.fchmod(fd,0o600)
with os.fdopen(fd,'w') as f:json.dump(data,f)
print('H3 PoC control directory ready; per-instance credential available:',bool(data.get('CONTAINER_API_KEY')))
PY
# Do not start vLLM or download models here. Upload authorization/rental/payload,
# arm guardian, accept hardware within 20 paid minutes, then proceed.
