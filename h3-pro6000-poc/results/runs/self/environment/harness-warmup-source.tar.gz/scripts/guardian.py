"""Server-only fail-safe. This operates only on this container's own instance.

At the hard stop or no valid self video by paid hour 2, a recorded explicit
emergency-release authorization is required. Normal release still follows archive verification.
No account-wide Vast key is uploaded; the provider supplies a per-instance key.
"""
import argparse
import json
import os
from pathlib import Path
import platform
import time
import urllib.error
import urllib.request

from common import ROOT, append, dump, epoch, load, require_authorization, utcnow


def destroy(instance_id, log):
    provider_credentials()
    container_id=os.environ.get("CONTAINER_ID")
    key=os.environ.get("CONTAINER_API_KEY")
    if str(instance_id)!=str(container_id) or not key:
        append(log,{"event":"guardian_cannot_destroy","utc":utcnow(),"reason":"per-instance identity or key missing"})
        return False
    url=f"https://console.vast.ai/api/v0/instances/{instance_id}/"
    req=urllib.request.Request(url,method="DELETE",headers={"Authorization":"Bearer "+key,"Content-Type":"application/json"},data=b'{}')
    try:
        with urllib.request.urlopen(req,timeout=15) as r:
            data=json.load(r)
        append(log,{"event":"destroy_response","utc":utcnow(),"response":data})
        return bool(data.get("success"))
    except (OSError,ValueError,urllib.error.URLError) as e:
        append(log,{"event":"destroy_error","utc":utcnow(),"exception_type":type(e).__name__});return False


def provider_credentials():
    if os.environ.get("CONTAINER_ID") and os.environ.get("CONTAINER_API_KEY"):return
    p=Path("/data/h3-control/instance-auth.json")
    if p.is_file() and p.stat().st_mode & 0o077==0:
        d=load(p)
        for n in ("CONTAINER_ID","CONTAINER_API_KEY"):
            if d.get(n):os.environ.setdefault(n,str(d[n]))


if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--run-dir",type=Path,required=True);p.add_argument("--rental",type=Path,required=True);p.add_argument("--authorization",type=Path,default=ROOT/"private/authorization.json");a=p.parse_args()
    if platform.system()!="Linux":raise SystemExit("只在服务器执行")
    auth=require_authorization(a.authorization,"allow_emergency_destroy_at_hard_stop")
    rental=load(a.rental)
    provider_credentials()
    if str(rental["instance_id"])!=str(os.environ.get("CONTAINER_ID")):raise RuntimeError("拒绝操作其他实例")
    if not os.environ.get("CONTAINER_API_KEY"):raise RuntimeError("缺少 provider 提供的实例级 Key；不要上传账户 Key")
    hard=epoch(rental["hard_release_utc"])
    hardware_deadline=epoch(rental["started_utc"])+20*60
    prior=float(rental.get("gpu_hours_before_this_rental",0))
    first=epoch(rental["started_utc"])+max(0,120*60-prior*3600)
    if hard-epoch(rental["started_utc"])+prior*3600>8*3600:raise RuntimeError("硬释放边界超过本轮累计上限")
    log=a.run_dir/"cost/guardian.jsonl"
    append(log,{"event":"guardian_armed","utc":utcnow(),"instance_id":rental["instance_id"],"hard_release_utc":rental["hard_release_utc"],"first_video_deadline_epoch":first})
    while True:
        now=time.time()
        first_missing=now>=first and not (a.run_dir/"FIRST_VALID_SELF_VIDEO.json").exists()
        hardware_missing=now>=hardware_deadline and not (a.run_dir/"HARDWARE_ACCEPTED.json").exists()
        if now>=hard or first_missing or hardware_missing:
            append(log,{"event":"emergency_release_trigger","utc":utcnow(),"reason":"hardware_not_accepted_by_paid_20m" if hardware_missing else "no_valid_self_video_by_paid_2h" if first_missing else "hard_release_boundary",
                        "note":"incremental archive should already be copied locally; local controller must verify final billing/release separately"})
            (a.run_dir/"STOP_SUBMISSIONS").touch()
            for _ in range(3):
                if destroy(rental["instance_id"],log):raise SystemExit(0)
                time.sleep(3)
            raise SystemExit("紧急释放未确认：本地控制器必须立即处理")
        if now>=hard-25*60:(a.run_dir/"STOP_SUBMISSIONS").touch()
        time.sleep(min(5,max(.1,hard-now)))
