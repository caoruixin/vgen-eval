"""Read-only provider queries and small metadata only. Never rents or generates."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import urllib.request

from common import ROOT, dump, env_values, load, sha256, utcnow


def get_json(url, data=None, headers=None):
    req = urllib.request.Request(url, data=json.dumps(data).encode() if data is not None else None,
                                 headers={"User-Agent": "H3-PoC-preflight/1.0", **({"Content-Type": "application/json"} if data is not None else {}), **(headers or {})})
    with urllib.request.urlopen(req, timeout=45) as r:
        return json.load(r)


def refresh_models(out):
    cfg = load(ROOT / "config/baseline.json")
    repo, rev = cfg["model_repo"], cfg["model_revision"]
    url = f"https://huggingface.co/api/models/{repo}/revision/{rev}?blobs=true"
    m = get_json(url)
    dump(out / "hf-model.json", m)
    files = [{"path": f["rfilename"], "size": f["size"], "sha256": f.get("lfs", {}).get("sha256"), "git_blob_sha1": f.get("blobId")}
             for f in m["siblings"] if f["rfilename"].startswith("FL2VA/")]
    if m["sha"] != rev or m.get("gated") or len(files) != 81 or sum(f["size"] for f in files) != 144051182625:
        raise RuntimeError("模型访问或文件列表与冻结基线不一致")
    with urllib.request.urlopen(f"https://huggingface.co/{repo}/resolve/{rev}/FL2VA/model_index.json", timeout=30) as r:
        idx = r.read(65536)
        if r.status != 200:
            raise RuntimeError("匿名 model_index 访问失败")
    dump(ROOT / "config/model-files.lock.json", {"repo": repo, "revision": rev, "partition": "FL2VA/", "gated": m.get("gated"),
         "total_bytes": sum(f["size"] for f in files), "files": files, "source": url, "observed_utc": utcnow()})
    dump(out / "h3-model-index.json", json.loads(idx))
    turbo = cfg["turbo"]
    t = get_json(f"https://huggingface.co/api/models/{turbo['repo']}/revision/{turbo['revision']}?blobs=true")
    tf = next(f for f in t["siblings"] if f["rfilename"] == turbo["filename"])
    if tf["lfs"]["sha256"] != turbo["sha256"] or tf["size"] != turbo["size_bytes"]:
        raise RuntimeError("Turbo 文件校验信息发生变化")
    dump(out / "hf-turbo.json", t)
    tag = get_json("https://api.github.com/repos/vllm-project/vllm-omni/git/ref/tags/v0.32.0")
    obj = tag["object"]
    if obj["type"] == "tag":
        obj = get_json(obj["url"])["object"]
    if obj["type"] != "commit" or obj["sha"] != cfg["source_commit"]:
        raise RuntimeError("v0.32.0 tag 与冻结源码 commit 不同")
    dump(out / "resolved-source.json", {"tag": tag, "commit": obj, "observed_utc": utcnow()})
    d = get_json("https://hub.docker.com/v2/repositories/vllm/vllm-omni/tags/v0.32.0")
    amd = next(i for i in d["images"] if i["architecture"] == "amd64" and i["os"] == "linux")
    if not cfg["image"].endswith(amd["digest"]):
        raise RuntimeError("官方镜像摘要不同")
    dump(out / "docker-tag.json", d)
    # Registry bearer token is anonymous/public, held only in memory.
    token = get_json("https://auth.docker.io/token?service=registry.docker.io&scope=repository:vllm/vllm-omni:pull")["token"]
    auth = {"Authorization": "Bearer " + token}
    manifest = get_json("https://registry-1.docker.io/v2/vllm/vllm-omni/manifests/" + amd["digest"],
                        headers={**auth, "Accept": "application/vnd.oci.image.manifest.v1+json,application/vnd.docker.distribution.manifest.v2+json"})
    image_cfg = get_json("https://registry-1.docker.io/v2/vllm/vllm-omni/blobs/" + manifest["config"]["digest"], headers=auth)
    dump(out / "image-manifest.json", manifest)
    dump(out / "image-config.json", image_cfg)
    return {"files": len(files), "model_bytes": sum(f["size"] for f in files), "image_compressed_bytes": amd["size"],
            "image_uncompressed_bytes": None, "image_config_entrypoint": image_cfg.get("config", {}).get("Entrypoint"),
            "runtime_env": [s for s in image_cfg.get("config", {}).get("Env", []) if s.startswith(("CUDA_", "NVIDIA_REQUIRE_CUDA", "NV_CUDA", "PATH="))]}


def refresh_offers(out):
    q = {"verified": {"eq": True}, "external": {"eq": False}, "rentable": {"eq": True}, "rented": {"eq": False},
         "gpu_name": {"eq": "RTX PRO 6000 S"}, "num_gpus": {"eq": 8}, "disk_space": {"gte": 500},
         "allocated_storage": 500, "type": "on-demand", "limit": 40, "order": [["dph_total", "asc"]]}
    url = "https://console.vast.ai/api/v0/bundles/"
    d = get_json(url, q)
    observed = utcnow()
    dump(out / "vast-offers.json", {"observed_utc": observed, "source": url, "query": q, "response": d})
    result = []
    for o in d.get("offers", []):
        gpu, disk = o["dph_base"], o["storage_total_cost"]
        # Conservative decimal GB for traffic; source labels are retained verbatim.
        traffic_normal = 180 * o["inet_down_cost"] + 20 * o["inet_up_cost"]
        traffic_replacement = 330 * o["inet_down_cost"] + 20 * o["inet_up_cost"]
        totals = {"6h40m_estimate_usd": (gpu + disk) * (6 + 40/60) + traffic_normal + 4,
                  "8h_10api_330GBin_20GBout_usd": (gpu + disk) * 8 + traffic_replacement + 4}
        reasons = []
        if gpu > 15: reasons.append("GPU 超过 $15/h")
        if o.get("gpu_frac") != 1: reasons.append("非整机完整 8 卡")
        if o.get("cpu_ram", 0) < 384 * 1024: reasons.append("主机 RAM 小于 384GiB")
        if o.get("inet_down", 0) < 500: reasons.append("下载带宽不足 500Mbps")
        if o.get("reliability2", o.get("reliability", 0)) < .99: reasons.append("可靠度低于 99%")
        if o.get("dlperf", 0) < 1000: reasons.append("DLPerf 低于 1000，仅筛选信号")
        result.append({"observed_utc": observed, "offer_id": o["id"], "machine_id": o["machine_id"], "region": o["geolocation"],
                       "gpu": o["gpu_name"], "num_gpus": o["num_gpus"], "gpu_ram_MiB": o["gpu_ram"], "cpu_ram_MiB": o["cpu_ram"],
                       "cpu": o["cpu_name"], "driver_listing_unverified": o.get("driver_version"), "max_cuda_listing": o.get("cuda_max_good"),
                       "verified": o.get("verification"), "reliability": o.get("reliability2", o.get("reliability")), "dlperf": o.get("dlperf"),
                       "download_Mbps": o["inet_down"], "upload_Mbps": o["inet_up"], "disk_MBps": o["disk_bw"],
                       "max_disk_listing_GB": o["disk_space"], "allocated_disk_at_creation_GB": 500,
                       "gpu_hour_usd": gpu, "disk_hour_usd": disk, "total_hour_before_traffic_usd": o["dph_total"],
                       "disk_GB_month_usd": o["storage_cost"], "download_GB_usd": o["inet_down_cost"], "upload_GB_usd": o["inet_up_cost"],
                       "maximum_duration_seconds": o["duration"], "host_contract_end_epoch": o["end_date"], "cautions": reasons,
                       "unknown": ["真实 GPU/显存/MIG/PCIe/NUMA/P2P/NCCL", "宿主驱动实际版本", "税费和充值附加费", "下单时库存", "镜像 SSH 注入能否成功"],
                       "cost_assumptions": {"normal_in_GB": 180, "replacement_in_GB": 330, "out_GB": 20, "official_api_10_estimate_usd": 4, "tax_and_deposit_fees": "unknown"},
                       **totals})
    result.sort(key=lambda x: (bool(x["cautions"]), x["region"] != "Texas, US", -x["reliability"], x["gpu_hour_usd"]))
    dump(out / "offer-review.json", {"observed_utc": observed, "offers": result})
    return result


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--models", action="store_true")
    p.add_argument("--offers", action="store_true")
    p.add_argument("--env-status", action="store_true")
    a = p.parse_args()
    out = ROOT / "research/upstream"
    out.mkdir(parents=True, exist_ok=True)
    summary = {"observed_utc": utcnow(), "paid_actions": 0}
    if a.models: summary["models"] = refresh_models(out)
    if a.offers: summary["offers"] = refresh_offers(out)
    if a.env_status:
        env_path = ROOT.parent / ".env"
        before = sha256(env_path)
        v = env_values(env_path, {"MINIMAX_BASE_URL", "MINIMAX_API_KEY"}, prefer_file=True)
        summary["environment"] = {"base_url_is_official": v.get("MINIMAX_BASE_URL", "").rstrip("/") == "https://api.minimax.io",
                                  "key_present": bool(v.get("MINIMAX_API_KEY")), "authentication_tested": False,
                                  "balance_tested": False, "env_unchanged": before == sha256(env_path)}
    dump(ROOT / "qa/preflight-latest.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
