"""Run inside the rented container only; no local environment installation."""
import argparse
import csv
import io
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import time

from common import dump, sha256, utcnow


def capture(command, directory, name, timeout=45):
    t=time.monotonic()
    try:
        p=subprocess.run(command,capture_output=True,text=True,timeout=timeout)
        result={"command":command,"exit_code":p.returncode,"stdout":p.stdout,"stderr":p.stderr,"elapsed_seconds":time.monotonic()-t}
    except (OSError,subprocess.TimeoutExpired) as e:
        result={"command":command,"exit_code":None,"error_type":type(e).__name__,"elapsed_seconds":time.monotonic()-t}
    dump(directory/(name+".json"),result)
    if result.get("stdout"):(directory/(name+".txt")).write_text(result["stdout"])
    return result


def main():
    p=argparse.ArgumentParser();p.add_argument("--out",type=Path,required=True);a=p.parse_args()
    if platform.system()!="Linux":raise SystemExit("本脚本只在租用的 GPU 服务器执行")
    a.out.mkdir(parents=True,exist_ok=True)
    begin=utcnow()
    captures={}
    for key,command in {
        "nvidia-list":["nvidia-smi","-L"],"nvidia-detail":["nvidia-smi","-q"],"topology":["nvidia-smi","topo","-m"],
        "nvlink":["nvidia-smi","nvlink","-s"],"numa":["numactl","--hardware"],"cpu":["lscpu"],
        "disk":["df","-B1","/data"],"mounts":["findmnt","-T","/data"],"pci":["lspci","-tv"],
        "driver":["nvidia-smi","--query-gpu=index,name,memory.total,driver_version,pci.bus_id,mig.mode.current","--format=csv,noheader,nounits"],
        "ffmpeg":["ffmpeg","-version"],"ffprobe":["ffprobe","-version"],"omni-cli":["vllm","serve","--help"],
    }.items():captures[key]=capture(command,a.out,key,timeout=90 if key=="omni-cli" else 40)
    issues=[]
    if captures["driver"].get("exit_code")!=0:issues.append("nvidia-smi 查询失败")
    rows=list(csv.reader(io.StringIO(captures["driver"].get("stdout",""))))
    if len(rows)!=8:issues.append("GPU 数不是 8")
    if len({row[4].strip() for row in rows if len(row)>=6})!=8:issues.append("PCI bus ID 不是8个不同设备")
    for row in rows:
        if len(row)<6:issues.append("GPU 查询字段缺失");continue
        if "RTX PRO 6000" not in row[1] or "Server" not in row[1]:issues.append("非 PRO 6000 Server Edition")
        if float(row[2].strip())<95000:issues.append("某张卡可见显存不符合 96GB 完整卡")
        if row[5].strip().lower() not in ("disabled","[n/a]","n/a"):issues.append("MIG 未确认关闭")
        if int(row[3].strip().split('.')[0])<580:issues.append("宿主驱动低于 CUDA 13.x 的 R580 基线")
    if "MIG " in captures["nvidia-list"].get("stdout",""):issues.append("发现 MIG 实例")
    ram=os.sysconf("SC_PAGE_SIZE")*os.sysconf("SC_PHYS_PAGES")
    effective_ram=ram
    for memory_limit in (Path('/sys/fs/cgroup/memory.max'),Path('/sys/fs/cgroup/memory/memory.limit_in_bytes')):
        if memory_limit.exists():
            value=memory_limit.read_text().strip()
            if value.isdigit():effective_ram=min(effective_ram,int(value))
    if effective_ram<384*1024**3:issues.append("主机/容器有效 RAM 不足 384GiB")
    disk=shutil.disk_usage("/data")
    if disk.free<220*1024**3:issues.append("下载前剩余磁盘不足 220GiB")
    if captures["topology"].get("exit_code")!=0 or captures["numa"].get("exit_code")!=0:issues.append("缺少 PCIe/NUMA 验收信息")
    for k in ("ffmpeg","ffprobe"):
        if captures[k].get("exit_code")!=0:issues.append(k+" 缺失，需在服务器准备后再继续")
    try:
        import torch
        import importlib.metadata as im
        packages={}
        for n in ("vllm","vllm-omni","huggingface-hub","diffusers","transformers","peft"):
            try:packages[n]=im.version(n)
            except im.PackageNotFoundError:packages[n]=None
        versions={"python":platform.python_version(),"torch":torch.__version__,"torch_cuda":torch.version.cuda,"cudnn":torch.backends.cudnn.version(),"nccl":torch.cuda.nccl.version(),"packages":packages}
        versions["peer_access"]=[[torch.cuda.can_device_access_peer(i,j) if i!=j else True for j in range(8)] for i in range(8)]
        versions["capability"]=[list(torch.cuda.get_device_capability(i)) for i in range(8)]
        if not (versions["packages"]["vllm-omni"] or "").startswith("0.32.0"):issues.append("镜像内 vllm-omni 包版本不符")
        dump(a.out/"runtime-versions.json",versions)
    except Exception as e:issues.append("Torch/运行时读取失败: "+type(e).__name__)
    summary={"started_utc":begin,"finished_utc":utcnow(),"basic_checks_passed":not issues,"issues":issues,"ram_bytes":ram,"effective_ram_limit_bytes":effective_ram,
             "filesystem_reported_total_bytes":disk.total,"filesystem_reported_free_bytes":disk.free,
             "disk_allocation_note":"df 可能反映宿主文件系统，500GB 合同配额需以 Vast 实例创建/账单证据另行确认",
             "topology_sha256":sha256(a.out/"topology.txt") if (a.out/"topology.txt").exists() else None,
             "acceptance_status":"pending NCCL all-reduce/all-to-all and topology mapping review"}
    dump(a.out/"hardware-summary.json",summary);print(json.dumps(summary,ensure_ascii=False,indent=2))
    raise SystemExit(0 if not issues else 1)


if __name__=="__main__":main()
