"""Standard-library utilities. Never source .env or log request headers."""
from __future__ import annotations

import contextlib
import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
from urllib.parse import urlsplit, urlunsplit

ROOT = Path(__file__).resolve().parents[1]


def utcnow():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="milliseconds")


def epoch(value):
    return dt.datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def canonical(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()


def digest(obj):
    return hashlib.sha256(canonical(obj)).hexdigest()


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def dump(path, obj, private=False):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=p.name + ".", dir=p.parent)
    try:
        if private:
            os.fchmod(fd, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2, allow_nan=False)
            f.write("\n")
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, p)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


@contextlib.contextmanager
def file_lock(path):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("a") as f:
        fcntl.flock(f, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(f, fcntl.LOCK_UN)


def append(path, obj):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with file_lock(str(p) + ".lock"):
        with p.open("a", encoding="utf-8") as f:
            f.write(json.dumps(redact(obj), ensure_ascii=False, allow_nan=False) + "\n")
            f.flush()
            os.fsync(f.fileno())


def read_jsonl(path):
    p = Path(path)
    if not p.exists():
        return []
    return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]


SECRET_NAMES = re.compile(r"authorization|api.?key|access.?token|password|secret|container_api", re.I)


def redact(obj):
    if isinstance(obj, dict):
        return {k: "[REDACTED]" if SECRET_NAMES.search(k) else redact(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [redact(v) for v in obj]
    if isinstance(obj, str):
        if obj.startswith("data:"):
            return "[DATA_URL length=%d sha256=%s]" % (len(obj), hashlib.sha256(obj.encode()).hexdigest())
        if obj.startswith(("https://", "http://")):
            u = urlsplit(obj)
            return urlunsplit((u.scheme, u.hostname or "", u.path, "[REDACTED]" if u.query else "", ""))
        obj = re.sub(r"(?i)Bearer\s+\S+", "Bearer [REDACTED]", obj)
        obj = re.sub(r"\b(?:sk|eyJ)[A-Za-z0-9_.-]{20,}\b", "[REDACTED]", obj)
    return obj


def env_values(path, names, prefer_file=False):
    """Read only named simple dotenv assignments; no interpolation or shell execution."""
    result = {n: os.environ[n] for n in names if n in os.environ}
    p = Path(path)
    if p.exists():
        for line in p.read_text().splitlines():
            m = re.match(r"^\s*(?:export\s+)?([A-Za-z_]\w*)\s*=\s*(.*?)\s*$", line)
            if m and m[1] in names and (prefer_file or m[1] not in result):
                value = m[2]
                if value[:1] in ("'", '"') and value[-1:] == value[:1]:
                    value = value[1:-1]
                else:
                    value = re.split(r"\s+#", value, maxsplit=1)[0]
                result[m[1]] = value
    return result


def require_authorization(path, capability):
    a = load(path)
    if not a.get("authorized") or not a.get("user_authorization_quote") or not a.get("authorized_at_utc"):
        raise RuntimeError("尚未记录用户明确的收费授权")
    if a.get("control_method") not in ("agent_browser_ssh", "user_checkout_ssh", "vast_cli_ssh"):
        raise RuntimeError("尚未选定租机控制方式")
    if not a.get(capability):
        raise RuntimeError("授权未包含 " + capability)
    caps = load(ROOT / "config/baseline.json")["limits"]
    for k in ("total_usd", "gpu_usd", "storage_network_usd", "api_usd", "gpu_hours", "gpu_rate_usd_hour_max"):
        if not isinstance(a.get("limits", {}).get(k), (int, float)) or not 0 < a["limits"][k] <= caps[k]:
            raise RuntimeError("授权预算缺失或超出已定上限: " + k)
    return a
