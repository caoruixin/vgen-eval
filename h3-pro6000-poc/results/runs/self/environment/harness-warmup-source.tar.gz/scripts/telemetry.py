"""Sample eight GPUs once per second without dumping environment variables."""
import argparse
import csv
import io
from pathlib import Path
import subprocess
import time

from common import append, utcnow

FIELDS="index,uuid,utilization.gpu,utilization.memory,memory.used,memory.total,power.draw,power.limit,temperature.gpu,clocks.sm,clocks.mem,pstate,pcie.link.gen.current,pcie.link.width.current"


if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--out",type=Path,required=True);p.add_argument("--seconds",type=int,default=8*3600);a=p.parse_args()
    deadline=time.monotonic()+a.seconds;next_tick=time.monotonic()
    while time.monotonic()<deadline and not a.out.with_suffix(".stop").exists():
        started=time.monotonic()
        r=subprocess.run(["nvidia-smi","--query-gpu="+FIELDS,"--format=csv,noheader,nounits"],capture_output=True,text=True,timeout=10)
        rows=list(csv.reader(io.StringIO(r.stdout))) if r.returncode==0 else []
        append(a.out,{"utc":utcnow(),"monotonic":started,"fields":FIELDS.split(","),"gpu":rows,"exit_code":r.returncode,"query_seconds":time.monotonic()-started,
                      "error":r.stderr[:500] if r.returncode else None})
        next_tick+=1
        time.sleep(max(0,next_tick-time.monotonic()))
