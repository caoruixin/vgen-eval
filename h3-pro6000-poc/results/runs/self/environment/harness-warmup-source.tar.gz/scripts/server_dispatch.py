"""Start one recorded server task with detached IO; never run on the laptop."""
import argparse,json,os,platform,subprocess
from pathlib import Path
from common import ROOT,dump,utcnow
p=argparse.ArgumentParser();p.add_argument('--name',required=True);p.add_argument('--log',type=Path,required=True);p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args()
if platform.system()!='Linux':raise SystemExit('Server only')
cmd=a.command[1:] if a.command[:1]==['--'] else a.command
if not cmd:raise SystemExit('Missing command')
prior=ROOT/'runs/self/processes'/(a.name+'.json')
if prior.is_file():
    old=json.loads(prior.read_text())
    proc=Path('/proc')/str(old['pid'])
    if proc.is_dir() and old.get('command')==cmd:
        print(json.dumps({'already_running':True,**old}));raise SystemExit(0)
a.log.parent.mkdir(parents=True,exist_ok=True)
with a.log.open('ab',buffering=0) as log:
    proc=subprocess.Popen(cmd,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,close_fds=True)
r={'utc':utcnow(),'pid':proc.pid,'pgid':proc.pid,'command':cmd,'log':str(a.log)}
dump(ROOT/'runs/self/processes'/(a.name+'.json'),r);print(json.dumps(r))
