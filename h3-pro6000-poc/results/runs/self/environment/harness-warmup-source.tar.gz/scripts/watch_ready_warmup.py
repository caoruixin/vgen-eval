"""Server coordinator with strict phase gates; no retries or invented measurements."""
import json,platform,subprocess,time,urllib.request
from common import ROOT,append,dump,load,utcnow
if platform.system()!='Linux':raise SystemExit('Server only')
r=ROOT/'runs/self';deadline=time.time()+70*60
while True:
    if time.time()>deadline or (r/'STOP_SUBMISSIONS').exists():raise SystemExit('Readiness wait stopped')
    try:
        with urllib.request.urlopen('http://127.0.0.1:8091/health',timeout=3) as resp:ready=resp.status==200
        if ready:break
    except OSError:pass
    time.sleep(5)
with urllib.request.urlopen('http://127.0.0.1:8091/openapi.json',timeout=10) as resp:dump(r/'environment/served-openapi.json',json.load(resp))
append(r/'deploy/stages.jsonl',{'event':'http_service_ready','utc':utcnow()})
for phase,want in (('warmup',4),('baseline',42)):
    done=subprocess.run(['python3','scripts/run.py','--phase',phase,'--run-dir','runs/self','--execute'],cwd=ROOT)
    rows=[load(p) for p in (r/'records').glob('*.json') if load(p).get('phase')==phase]
    valid=sum(x.get('status')=='validated' for x in rows)
    append(r/'deploy/stages.jsonl',{'event':'phase_gate','utc':utcnow(),'phase':phase,'expected':want,'records':len(rows),'valid':valid,'exit_code':done.returncode})
    if done.returncode or len(rows)!=want or valid!=want:
        dump(r/'CONTROL_NEEDS_ATTENTION.json',{'utc':utcnow(),'phase':phase,'records':len(rows),'valid':valid,'reason':'phase incomplete; do not resubmit automatically'})
        raise SystemExit('Phase gate stopped')
