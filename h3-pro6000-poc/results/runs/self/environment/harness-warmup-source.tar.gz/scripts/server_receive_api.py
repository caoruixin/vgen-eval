"""Fetch already-created official outputs on this server using signed download URLs only."""
import json,platform,sys
from common import ROOT,sha256
from providers import Client
if platform.system()!='Linux':raise SystemExit('Server only')
items=json.load(sys.stdin);cfg=json.loads((ROOT/'config/baseline.json').read_text())
c=Client('official_api','https://api.minimax.io',cfg,ROOT/'runs/api/server-fetch.jsonl')
for item in items:
    name=item['request_id']
    if '/' in name or not name.startswith('comparison-official_api-'):raise SystemExit('Invalid request id')
    dest=ROOT/'runs/api/outputs'/(name+'.mp4')
    if not dest.exists() or sha256(dest)!=item['sha256']:
        c.download(item['task_id'],{'content':{'url':item['url']}},dest)
    if sha256(dest)!=item['sha256']:raise SystemExit('Output SHA256 mismatch')
    print(json.dumps({'request_id':name,'bytes':dest.stat().st_size,'sha256_verified':True}))
