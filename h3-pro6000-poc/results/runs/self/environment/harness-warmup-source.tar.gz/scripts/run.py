"""Defaults to an offline plan. --execute requires a recorded user authorization."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
import csv
import datetime as dt
import json
from pathlib import Path
import platform
import subprocess
import time

from budget import Ledger
from common import ROOT, append, canonical, digest, dump, env_values, epoch, file_lock, load, read_jsonl, redact, require_authorization, sha256, utcnow
from media import binary, validate
from providers import Client, ProviderError, minimax_payload, vllm_fields


def verify_frozen():
    matrix = load(ROOT / "cases/matrix.lock.json")
    for file, field in (("cases/cases.json","cases_sha256"),("cases/assets.lock.json","assets_manifest_sha256"),("config/baseline.json","config_sha256")):
        if sha256(ROOT / file) != matrix[field]:
            raise RuntimeError("冻结文件已变化: " + file)
    for a in load(ROOT / "cases/assets.lock.json")["assets"]:
        if sha256(ROOT / a["file"]) != a["sha256"]:
            raise RuntimeError("首帧已变化: " + a["case_id"])
    return matrix


def export_csv(run_dir):
    rows=[]
    for p in sorted((Path(run_dir)/"records").glob("*.json")):
        x=load(p)
        m=x.get("media",{})
        row={k:x.get(k) for k in ("request_id","attempt","case_id","task","phase","provider","variant","transport","seed","requested_num_inference_steps","actual_denoise_updates","actual_denoise_updates_source","task_id","status","submitted","submitted_utc","task_id_saved_utc","terminal_utc","downloaded_utc","finished_utc","e2e_seconds","submit_to_terminal_seconds","poll_interval_seconds","poll_detection_bound_seconds","server_inference_time_s","server_peak_memory_mb","error","ambiguous_submission","config_sha256","matrix_sha256","prompt_sha256","asset_sha256","model_revision","api_reserved_usd","api_cost_estimate_usd","api_cost_source","ledger_reservation_id","video_path")}
        row.update({k:m.get(k) for k in ("technical_valid","width","height","fps","frames","duration_seconds","audio_duration_seconds","audio_channels","audio_sample_rate","decode_exit_code","validation_seconds","sha256")})
        row["spec_deviations"]=json.dumps(m.get("spec_deviations"),ensure_ascii=False)
        row["quality_status"]="pending_user_review"
        row["stage_durations"]=json.dumps(x.get("stage_durations"),ensure_ascii=False)
        row["usage"]=json.dumps(x.get("usage"),ensure_ascii=False)
        row["versions"]=json.dumps(x.get("versions"),ensure_ascii=False)
        rows.append(row)
    if rows:
        p=Path(run_dir)/"results.csv"
        # Called only outside worker threads; one writer per run command.
        with p.open("w",newline="",encoding="utf-8-sig") as f:
            writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    return rows


def transport_for(case, requested="auto"):
    if case["provider"]=="official_api":return "async"
    if requested!="auto":return requested
    if case["phase"].startswith("concurrency") or case["phase"]=="turbo":return "async"
    if case["phase"]=="warmup" and case["seed"]==9002:return "async"
    return "sync"


def one(case, cfg, client, run_dir, ledger, phase_deadline=None, resume=False, validation=validate, retry_rejected=False):
    claim=Path(run_dir)/"records"/(case["request_id"]+".claim.lock")
    with file_lock(claim):
        return _one(case,cfg,client,run_dir,ledger,phase_deadline,resume,validation,retry_rejected)


def _one(case, cfg, client, run_dir, ledger, phase_deadline=None, resume=False, validation=validate, retry_rejected=False):
    run_dir=Path(run_dir)
    if (run_dir/"STOP_SUBMISSIONS").exists() and not resume:
        raise RuntimeError("已进入归档/停止阶段，禁止新提交")
    path=run_dir/"records"/(case["request_id"]+".json")
    previous=None;prior_attempt_file=None
    if path.exists() and not resume:
        previous=load(path)
        if not (retry_rejected and previous.get("confirmed_input_rejection") is True and previous.get("http_status")==400 and previous.get("ambiguous_submission") is False):
            raise RuntimeError("已有提交意图/结果；不可自动重提: "+case["request_id"])
        prior_attempt_file="attempts/"+case["request_id"]+"-attempt-"+str(previous.get("attempt",1))+".json"
        dump(run_dir/prior_attempt_file,previous)
    r=load(path) if resume else {k:case.get(k) for k in ("request_id","case_id","task","phase","provider","variant","seed","prompt_sha256","asset_sha256")}
    if prior_attempt_file:r["prior_attempt_file"]=prior_attempt_file
    if resume and not r.get("task_id"):
        raise RuntimeError("无 task_id，先 list-tasks 核实；禁止盲重试")
    if resume and r.get("transport")=="sync":
        raise RuntimeError("同步响应断开无法据 ID 自动重新生成，需核实服务日志")
    if resume and r.get("status")=="validated":return r
    r.update({"attempt":r.get("attempt",previous.get("attempt",1)+1 if previous else 1),"config_sha256":sha256(ROOT/"config/baseline.json"),"matrix_sha256":sha256(ROOT/"cases/matrix.lock.json"),
              "model_revision":cfg["model_revision"] if case["provider"]=="self" else "not_exposed_by_official_api",
              "poll_interval_seconds":client.poll,"transport":r.get("transport",case.get("transport","async"))})
    r["versions"]={"vllm_omni_tag":cfg["vllm_omni_tag"],"source_commit":cfg["source_commit"],"image":cfg["image"],
                   "harness_sha256":digest({p.name:sha256(p) for p in (ROOT/"scripts").glob("*.py")}),
                   "adapter_sha256":cfg["turbo"]["sha256"] if case["variant"]=="turbo8" else None}
    r["requested_num_inference_steps"]=(cfg["turbo"] if case["variant"]=="turbo8" else cfg)["num_inference_steps"] if case["provider"]=="self" else None
    r["actual_denoise_updates"]=r.get("actual_denoise_updates")  # Populate only from per-request server metrics/log evidence.
    r["actual_denoise_updates_source"]=r.get("actual_denoise_updates_source")
    r["return_stage_metrics_requested"]=case["provider"]=="self"
    video=run_dir/"outputs"/(case["request_id"]+".mp4")
    start=time.monotonic()
    task=None
    try:
        if not resume:
            if case["provider"]=="self":
                ledger.guard(next_gpu_seconds=cfg["request_timeout_seconds"]+300)
            else:
                # One 5s request at the verified price is $0.40. Hold a full $1 pending reconciliation.
                r["api_reserved_usd"]=1.0
                r["ledger_reservation_id"]=ledger.reserve("api",1.0,"published 768P price; conservative pending cap $1/request",case["request_id"])
            r.update(status="submission_intent",submitted=False,submitted_utc=utcnow())
            dump(path,r)
            append(run_dir/"requests.jsonl",{"event":"submission_intent",**r,"prompt":case["prompt"]})
            # Mark before writing to the socket: interrupted/ambiguous sends remain visible and cannot retry.
            r.update(submitted=True,status="submitting");dump(path,r)
            if r["transport"]=="sync":
                result=client.sync(case,video)
                r.update(task_id=result.get("task_id"),stage_durations=result.get("stage_durations"),server_inference_time_s=result.get("inference_time_s"),server_peak_memory_mb=result.get("peak_memory_mb"),terminal_utc=utcnow(),downloaded_utc=utcnow(),http=result)
                r["submit_to_terminal_seconds"]=time.monotonic()-start
            else:
                task_id,response=client.submit(case)
                r.update(task_id=task_id,task_id_saved_utc=utcnow(),status="accepted",create_response=redact(response))
                dump(path,r)  # Must complete/fsync before any polling or follow-up.
                append(run_dir/"requests.jsonl",{"event":"task_id_saved","request_id":case["request_id"],"task_id":task_id,"utc":utcnow()})
        else:
            r.setdefault("recovery_history",[]).append({"utc":utcnow(),"prior_status":r.get("status"),"prior_error":r.get("error"),"action":"query_and_download_existing_task_only"})
            r.pop("error",None);r["resumed_utc"]=utcnow();dump(path,r)
        if r["transport"]=="async":
            deadline=time.monotonic()+cfg["request_timeout_seconds"]
            if phase_deadline is not None: deadline=min(deadline,phase_deadline)
            last_poll=None
            errors=0
            while True:
                if time.monotonic()>=deadline:
                    if case["provider"]=="self":
                        try:
                            response=client.json_request("DELETE","/v1/videos/"+r["task_id"])
                            r["cancellation_response"]=redact(response)
                        except ProviderError:r["cancellation_response"]="failed; inspect service"
                    raise ProviderError("轮询/阶段时间到；仅停止此任务，不重提")
                ledger.guard(next_gpu_seconds=30 if case["provider"]=="self" else 0)
                try:
                    task,response=client.query(r["task_id"]);errors=0
                except ProviderError:
                    errors+=1
                    if errors>=3:raise
                    time.sleep(min(client.poll,1));continue  # GET only.
                status=task["status"]
                poll=time.monotonic()
                append(run_dir/"requests.jsonl",{"event":"poll","request_id":case["request_id"],"utc":utcnow(),"status":status,"elapsed_seconds":poll-start})
                if status in ("succeeded","completed"):
                    r.setdefault("terminal_utc",utcnow())
                    r.update(query_response=redact(response),usage=task.get("usage"),stage_durations=task.get("stage_durations"),server_metrics=task.get("metrics"),server_inference_time_s=task.get("inference_time_s"),server_peak_memory_mb=task.get("peak_memory_mb"))
                    if not resume:
                        r["submit_to_terminal_seconds"]=poll-start
                        r["poll_detection_bound_seconds"]=(poll-last_poll) if last_poll is not None else None
                    else:r["resume_query_to_terminal_seconds"]=poll-start
                    break
                if status in ("failed","cancelled","canceled"):
                    r["terminal_response"]=redact(response)
                    raise ProviderError("任务终止: "+status)
                if status not in ("queued","running","in_progress","pending"):
                    raise ProviderError("未知任务状态: "+str(status))
                last_poll=poll
                time.sleep(min(client.poll,max(0,deadline-time.monotonic())))
            r["http"]=client.download(r["task_id"],task,video)
            r["downloaded_utc"]=utcnow()
        r["e2e_seconds"]=(epoch(r["downloaded_utc"])-epoch(r["submitted_utc"])) if resume else time.monotonic()-start
        r.update(status="downloaded",video_path=str(video.relative_to(run_dir)))
        dump(path,r)
        r["media"]=validation(video,run_dir/"outputs"/case["request_id"],cfg if case["provider"]=="self" else None)
        valid=r["media"]["technical_valid"]
        r["status"]="downloaded_pending_server_validation" if valid is None else "validated" if valid else "invalid_media"
        if r["status"]=="validated" and case["provider"]=="self":
            marker=run_dir/"FIRST_VALID_SELF_VIDEO.json"
            if not marker.exists():dump(marker,{"utc":utcnow(),"request_id":case["request_id"],"sha256":r["media"]["sha256"]})
        if case["provider"]=="official_api":
            output_seconds=r.get("usage",{}).get("output_seconds") if r.get("usage") else None
            r.update(api_cost_estimate_usd=output_seconds*.08 if output_seconds is not None else None,
                     api_cost_source="usage.output_seconds × verified list price $0.08; not settled invoice")
            # Leave $1 reservation until the actual account charge is reconciled.
    except Exception as e:
        r.update(status="ambiguous_submission" if isinstance(e,ProviderError) and e.ambiguous else "failed",
                 ambiguous_submission=isinstance(e,ProviderError) and e.ambiguous,http_status=getattr(e,"http_status",None),error=str(redact(str(e)))[:1000])
    finally:
        r["finished_utc"]=utcnow();dump(path,r)
        append(run_dir/"requests.jsonl",{"event":"attempt_finished",**r})
    return r


def require_server():
    if platform.system()!="Linux":
        raise RuntimeError("自建执行只在租用的 Linux GPU 服务器进行；本机不安装推理环境")
    n=subprocess.run(["nvidia-smi","--query-gpu=name","--format=csv,noheader"],check=True,capture_output=True,text=True).stdout.strip().splitlines()
    if len(n)!=8 or any("RTX PRO 6000" not in s or "Server" not in s for s in n):
        raise RuntimeError("当前设备不是已验收的 8×PRO 6000 Server")


def deferred_media(path, evidence, expected=None):
    result={"path":str(path),"sha256":sha256(path),"technical_valid":None,"manual_av_sync":"pending",
            "reason":"按用户要求，ffprobe 和完整 ffmpeg 解码在服务器执行；此时仅通过 HTTP/Content-Type/ftyp 检查"}
    dump(Path(evidence)/"validation-pending.json",result)
    return result


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--phase",choices=["warmup","baseline","comparison","stability","concurrency_c2","concurrency_c4","turbo"],required=True)
    p.add_argument("--run-dir",type=Path,required=True)
    p.add_argument("--execute",action="store_true")
    p.add_argument("--case")
    p.add_argument("--limit",type=int)
    p.add_argument("--retry-confirmed-rejection",action="store_true",help="仅对经服务日志确认的HTTP400输入拒绝创建下一次独立尝试；默认禁止重提")
    p.add_argument("--skip-existing-completed",action="store_true",help="跳过已有成功下载/已校验记录；不重提，用于首条 API 样例计入整组10条")
    p.add_argument("--transport",choices=["auto","sync","async"],default="auto")
    p.add_argument("--authorization",type=Path,default=ROOT/"private/authorization.json")
    p.add_argument("--ledger",type=Path,default=ROOT/"private/ledger.json")
    p.add_argument("--base-url")
    p.add_argument("--resume",help="已有 request_id；只查询/下载，不重新 POST")
    p.add_argument("--list-tasks",action="store_true",help="只查询近 20 条，以核实超时创建")
    p.add_argument("--defer-media-validation-to-server",action="store_true",help="官方 API 样例仅下载；GPU 租前不在笔记本装 ffmpeg，稍后在服务器完整校验")
    a=p.parse_args()
    matrix=verify_frozen();cfg=load(ROOT/"config/baseline.json")
    selected=[dict(c) for c in matrix["requests"] if c["phase"]==a.phase and (not a.case or c["case_id"]==a.case)]
    if a.limit:selected=selected[:a.limit]
    if a.resume:selected=[c for c in selected if c["request_id"]==a.resume]
    if a.skip_existing_completed:
        keep=[]
        for c in selected:
            record=a.run_dir/"records"/(c["request_id"]+".json")
            if record.exists():
                if load(record).get("status") in ("validated","downloaded_pending_server_validation"):continue
                raise RuntimeError("存在未解决的提交/失败，先核实: "+c["request_id"])
            keep.append(c)
        selected=keep
    for c in selected:c["transport"]=transport_for(c,a.transport)
    a.run_dir.mkdir(parents=True,exist_ok=True)
    if not a.execute:
        planned=[{**c,"wire":redact(minimax_payload(c,cfg) if c["provider"]=="official_api" else vllm_fields(c,cfg))} for c in selected]
        dump(a.run_dir/("dry-run-"+a.phase+".json"),{"kind":"offline-dry-run","network_requests":0,"paid_actions":0,"matrix_sha256":sha256(ROOT/"cases/matrix.lock.json"),"requests":planned,"time_bounded_stability_policy":matrix["stability"] if a.phase=="stability" else None})
        print(json.dumps({"mode":"offline-dry-run","phase":a.phase,"requests":len(planned),"paid_actions":0},ensure_ascii=False));return
    provider="official_api" if a.phase=="comparison" else "self"
    require_authorization(a.authorization,"allow_official_api_generation" if provider=="official_api" else "allow_gpu_rental")
    if provider=="self":require_server()
    deferred=provider=="official_api" and (a.defer_media_validation_to_server or platform.system()!="Linux")
    if not deferred:binary("ffmpeg");binary("ffprobe")
    validator=deferred_media if deferred else validate
    ledger=Ledger(a.ledger);ledger.init()
    if provider=="self" and not ledger.snapshot()["open_rentals"]:
        raise RuntimeError("必须先登记实例开始计费时间、报价和硬释放时间")
    creds=env_values(ROOT.parent/".env",{"MINIMAX_API_KEY","MINIMAX_BASE_URL"},prefer_file=True) if provider=="official_api" else {}
    base=a.base_url or (creds.get("MINIMAX_BASE_URL","https://api.minimax.io") if provider=="official_api" else "http://127.0.0.1:8091")
    if provider=="official_api" and not creds.get("MINIMAX_API_KEY"):raise RuntimeError("已有官方 Key 不可读")
    run_manifest=a.run_dir/"run.json"
    if not run_manifest.exists():dump(run_manifest,{"kind":"measured","created_utc":utcnow(),"model_revision":cfg["model_revision"],"matrix_sha256":sha256(ROOT/"cases/matrix.lock.json"),"manual_quality":"pending_user_review"})
    elif load(run_manifest).get("kind")!="measured":raise RuntimeError("拒绝在 mock/dry-run 目录执行真实任务")
    client=Client(provider,base,cfg,a.run_dir/"http.jsonl",api_key=creds.get("MINIMAX_API_KEY"))
    if a.list_tasks:
        dump(a.run_dir/"recent-tasks.json",redact(client.list_recent()));print("已保存近 20 条任务；本命令没有提交任务");return
    durations={"warmup":3600,"baseline":7200,"comparison":7200,"stability":3600,"concurrency_c2":900,"concurrency_c4":900,"turbo":2700}
    duration=durations[a.phase]
    start_utc=utcnow();start=time.monotonic();deadline=start+duration
    results=[]
    if a.phase=="stability":
        cycle=load(ROOT/"cases/cases.json")["cases"];i=0
        while time.monotonic()<deadline:
            c0=cycle[i%len(cycle)]
            template=next(c for c in matrix["requests"] if c["case_id"]==c0["id"] and c["provider"]=="self")
            c={**template,"phase":"stability","seed":4101+i,"request_id":f"stability-self-bf16-{c0['id']}-{4101+i}","transport":"async"}
            r=one(c,cfg,client,a.run_dir,ledger,phase_deadline=deadline);results.append(r);export_csv(a.run_dir);i+=1
            if r["status"]!="validated":break
    elif a.phase.startswith("concurrency"):
        concurrency=2 if a.phase.endswith("c2") else 4
        ledger.guard(next_gpu_seconds=duration+300)
        with ThreadPoolExecutor(max_workers=concurrency) as pool:
            results=list(pool.map(lambda c:one(c,cfg,client,a.run_dir,ledger,phase_deadline=deadline,validation=validator),selected))
    else:
        for c in selected:
            if time.monotonic()>=deadline:break
            r=one(c,cfg,client,a.run_dir,ledger,phase_deadline=deadline,resume=bool(a.resume),validation=validator,retry_rejected=a.retry_confirmed_rejection);results.append(r);export_csv(a.run_dir)
            if r["status"] not in ("validated","downloaded_pending_server_validation"):break  # Resolve the first failure, never cascade/retry paid submissions.
    export_csv(a.run_dir)
    append(a.run_dir/"phase-windows.jsonl",{"phase":a.phase,"provider":provider,"start_utc":start_utc,"end_utc":utcnow(),"wall_seconds":time.monotonic()-start,"requests_this_invocation":len(results),"concurrency":2 if a.phase=="concurrency_c2" else 4 if a.phase=="concurrency_c4" else 1})
    print(json.dumps({"phase":a.phase,"results":[{k:r.get(k) for k in ("request_id","status","task_id","e2e_seconds")} for r in results]},ensure_ascii=False,indent=2))


if __name__=="__main__":
    main()
