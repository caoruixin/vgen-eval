"""Inspect installed pinned runtime contracts before model weights are loaded."""
import argparse
import inspect
from pathlib import Path
import platform
from types import SimpleNamespace

from common import ROOT,dump,load,sha256,utcnow

if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--out",type=Path,required=True);a=p.parse_args()
    if platform.system()!="Linux":raise SystemExit("只在服务器现成镜像中检查，不在笔记本安装/import H3 框架")
    from vllm_omni.diffusion.models.minimax_h3 import MiniMaxH3Pipeline
    from vllm_omni.diffusion.models.minimax_h3.lora import parse_turbo_filename
    from vllm_omni.diffusion.models.minimax_h3.time_request import minimax_h3_time_shift_sigmas
    cfg=load(ROOT/"config/baseline.json");t=cfg["turbo"]
    spec=parse_turbo_filename(t["filename"])
    pipeline=object.__new__(MiniMaxH3Pipeline);pipeline.default_video_shift=6;pipeline.default_audio_shift=3
    outcome={}
    for steps in (8,9):
        try:pipeline._validate_turbo_sampling(SimpleNamespace(num_inference_steps=steps,extra_args={"flow_shift":6,"audio_flow_shift":3}),spec);outcome[str(steps)]="accepted"
        except Exception as e:outcome[str(steps)]=type(e).__name__+": "+str(e)
    source=Path(inspect.getfile(MiniMaxH3Pipeline))
    result={"utc":utcnow(),"pipeline_source":str(source),"pipeline_source_sha256":sha256(source),"turbo_validation_without_loading_weights":outcome,
            "schedule_points_for_requested_50":len(minimax_h3_time_shift_sigmas(num_steps=50,shift_scale=12)),
            "note":"这是已安装源码/调度函数契约检查，不是已执行模型步数或性能实测。每条真实请求仍需日志/返回指标支持。"}
    dump(a.out,result)
    if outcome["8"]!="accepted" or outcome["9"]=="accepted":raise SystemExit("镜像运行时与固定源码契约不符：不要现场修框架或盲试 Turbo；先保留 BF16，Turbo 暂缓")
    print("Installed Turbo request contract verified: 8 evaluations, 9 sigma points.")
