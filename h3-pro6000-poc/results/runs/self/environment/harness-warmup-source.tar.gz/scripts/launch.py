"""Build a reviewable pinned command; --execute runs it only on the GPU server."""
import argparse
import json
import os
from pathlib import Path
import platform
import shlex
import subprocess

from budget import Ledger
from common import ROOT, dump, load, require_authorization, utcnow


def command(cfg, mapping, turbo=False, numa_mode="interleave"):
    order=mapping.get("gpu_order")
    nodes=mapping.get("numa_interleave_nodes")
    if not isinstance(order,list) or sorted(order)!=list(range(8)) or not isinstance(nodes,list) or not nodes or any(not isinstance(n,int) or n<0 for n in nodes):
        raise RuntimeError("必须先根据本机证据填写 GPU rank 顺序和 NUMA 节点")
    if not mapping.get("topology_sha256") or len(mapping.get("basis",""))<20:
        raise RuntimeError("缺少拓扑依据")
    env={"CUDA_VISIBLE_DEVICES":",".join(map(str,order)),"VLLM_WORKER_MULTIPROC_METHOD":"spawn","VLLM_OMNI_VIDEO_SYNC_TIMEOUT":"1800",
         "VLLM_OMNI_SERVER_STORAGE__PATH":"/data/h3-video-store","NCCL_DEBUG":"INFO","NCCL_DEBUG_SUBSYS":"INIT,GRAPH"}
    if numa_mode not in ("interleave","cpu-bind"):raise RuntimeError("Unknown NUMA mode")
    numa_flag="--interleave=" if numa_mode=="interleave" else "--cpunodebind="
    argv=["numactl",numa_flag+",".join(map(str,nodes)),"vllm","serve",cfg["model_path"],"--omni","--host","127.0.0.1","--port","8091","--trust-remote-code",
          "--num-gpus","8","--tensor-parallel-size","4","--usp","2","--ring","1","--text-encoder-tp-size","8","--vae-patch-parallel-size","8","--vae-parallel-mode","tile","--vae-use-tiling","--diffusion-attention-backend","CUDNN_ATTN"]
    if turbo:argv += ["--task-type","fl2va","--lora-backend","peft","--lora-path",cfg["turbo"]["path"]]
    return argv,env


if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--numa-mode",choices=["interleave","cpu-bind"],default="interleave");p.add_argument("--mapping",type=Path,required=True);p.add_argument("--out",type=Path,required=True);p.add_argument("--execute",action="store_true");p.add_argument("--turbo",action="store_true");p.add_argument("--authorization",type=Path,default=ROOT/"private/authorization.json");p.add_argument("--ledger",type=Path,default=ROOT/"private/ledger.json");a=p.parse_args()
    cfg=load(ROOT/"config/baseline.json");m=load(a.mapping);argv,env=command(cfg,m,a.turbo,a.numa_mode)
    a.out.mkdir(parents=True,exist_ok=True)
    dump(a.out/"launch-command.json",{"utc":utcnow(),"argv":argv,"explicit_environment":env,"turbo":a.turbo,"numa_mode":a.numa_mode,"numa_memory_policy_note":"container default; set_mempolicy denied" if a.numa_mode=="cpu-bind" else "requested interleave","image_expected":cfg["image"],
         "regional_compile":"upstream default retained; first warmup excluded","additional_approximate_optimization":"none requested","execute":a.execute})
    if not a.execute:
        print(" ".join(shlex.quote(k+"="+v) for k,v in env.items())+" "+shlex.join(argv));raise SystemExit(0)
    if platform.system()!="Linux":raise SystemExit("推理环境只在服务器运行")
    require_authorization(a.authorization,"allow_gpu_rental")
    ledger=Ledger(a.ledger)
    if not ledger.snapshot()["open_rentals"]:raise RuntimeError("未登记计费实例")
    ledger.guard(next_gpu_seconds=30*60)
    hw=load(m["hardware_summary"]);nccl=load(m["nccl_result"])
    if not hw["basic_checks_passed"] or hw["topology_sha256"]!=m["topology_sha256"] or not all(v["correct"] for v in nccl["results"].values()):
        raise RuntimeError("硬件/通信验收未通过")
    allocation=load(m["instance_allocation_evidence"])
    if allocation.get("disk_GB")!=500 or allocation.get("image")!=cfg["image"]:
        raise RuntimeError("500GB 合同磁盘或镜像摘要证据不符")
    os.environ.update(env)
    # Foreground process: invoke through nohup/tmux on the server; stdout/stderr is saved by the caller.
    os.execvp(argv[0],argv)
