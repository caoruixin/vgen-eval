"""Aggregate observed records only; a mock run can never become a measured report."""
import argparse
from collections import defaultdict
import csv
import json
import math
from pathlib import Path
import statistics

from common import dump, load, read_jsonl, utcnow


def quantile(values,p):
    if not values:return None
    values=sorted(values);index=(len(values)-1)*p;lo=math.floor(index);hi=math.ceil(index)
    return values[lo]+(values[hi]-values[lo])*(index-lo)


def summarize(rows,windows,gpu_rate=None,disk_rate=0):
    groups=defaultdict(list)
    for r in rows:
        if r.get("submitted"):groups[(r["provider"],r["phase"],r["variant"],r["task"],r.get("transport"))].append(r)
    result=[]
    for key,rs in sorted(groups.items(),key=lambda item:str(item[0])):
        provider,phase,variant,task,transport=key
        valid=[r for r in rs if r.get("media",{}).get("technical_valid") is True]
        latency=[r["e2e_seconds"] for r in valid if r.get("e2e_seconds") is not None]
        applicable=[w for w in windows if w["phase"]==phase and w["provider"]==provider]
        wall=sum(w["wall_seconds"] for w in applicable) if applicable else None
        # A mixed-task C2/C4 window is shared. Do not allocate the whole window to each task.
        all_group_success=sum(r.get("media",{}).get("technical_valid") is True for r in rows if r.get("provider")==provider and r.get("phase")==phase)
        phase_cost=(gpu_rate+disk_rate)*wall/3600 if wall is not None and gpu_rate is not None and provider=="self" else None
        result.append({"provider":provider,"phase":phase,"variant":variant,"task":task,"transport":transport,"n_submitted":len(rs),"n_technical_valid":len(valid),
                       "technical_success_rate":len(valid)/len(rs),"n_human_reviewed":0,"deliverable_rate":None,
                       "e2e_p50_seconds":quantile(latency,.5),"e2e_p95_seconds":quantile(latency,.95),"e2e_min_seconds":min(latency) if latency else None,"e2e_max_seconds":max(latency) if latency else None,
                       "phase_window_seconds_shared":wall,"phase_success_total_all_tasks":all_group_success,
                       "phase_success_per_hour_all_tasks":all_group_success/wall*3600 if wall else None,
                       "phase_window_cost_estimate_shared_usd":phase_cost,
                       "phase_cost_per_success_all_tasks_usd":phase_cost/all_group_success if phase_cost is not None and all_group_success else None,
                       "tail_caution":"P95 is preliminary; small n, not a production SLA" if len(latency)<100 else None})
    return result


def main():
    p=argparse.ArgumentParser();p.add_argument("run_dir",type=Path);p.add_argument("--gpu-hour-usd",type=float);p.add_argument("--disk-hour-usd",type=float,default=0);p.add_argument("--cold-start-usd",type=float);p.add_argument("--amortization-results",type=int);a=p.parse_args()
    manifest=load(a.run_dir/"run.json")
    if manifest.get("kind")!="measured":raise SystemExit("拒绝把 mock/dry-run 合并为实测报告")
    rows=[load(p) for p in (a.run_dir/"records").glob("*.json")]
    windows=read_jsonl(a.run_dir/"phase-windows.jsonl")
    summary=summarize(rows,windows,a.gpu_hour_usd,a.disk_hour_usd)
    telemetry=[]
    for p in (a.run_dir/"telemetry").glob("*.jsonl"):telemetry.extend(read_jsonl(p))
    peaks={}
    for sample in telemetry:
        for gpu in sample.get("gpu",[]):
            data=dict(zip(sample["fields"],gpu));idx=str(data.get("index","")).strip()
            try:peaks[idx]=max(peaks.get(idx,0),float(data["memory.used"].strip()))
            except (KeyError,ValueError):pass
    utilization=[]
    baseline=[r for r in rows if r.get("provider")=="self" and r.get("phase")=="baseline" and r.get("media",{}).get("technical_valid") is True]
    baseline_wall=sum(w["wall_seconds"] for w in windows if w["phase"]=="baseline" and w["provider"]=="self")
    if baseline and baseline_wall and a.gpu_hour_usd is not None:
        interval=baseline_wall/len(baseline)
        for u in (.25,.5,1.0):
            value={"utilization":u,"observed_baseline_seconds_per_success":interval,"steady_cost_per_success_usd":interval*(a.gpu_hour_usd+a.disk_hour_usd)/3600/u,
                   "cold_start_amortization_results":a.amortization_results,"cold_start_cost_usd":a.cold_start_usd}
            value["cold_amortization_per_result_usd"]=a.cold_start_usd/a.amortization_results if a.cold_start_usd is not None and a.amortization_results else None
            utilization.append(value)
    out={"generated_utc":utcnow(),"kind":"observed_summary","groups":summary,"sampled_peak_memory_MiB_by_GPU":peaks,"utilization_estimates":utilization,
         "quality":"pending user review; technical success is not deliverability","cost":"estimates from measured windows; invoices/pending ledger reconciled separately",
         "limitations":["warmup, baseline, stability, concurrency and Turbo are separate","C2/C4 throughput and cost use the entire shared wall-clock once","no stage timing is inferred where logs/headers do not expose it","manual audio/visual sync cannot be inferred from ffprobe"]}
    dump(a.run_dir/"analysis/summary.json",out)
    if summary:
        with (a.run_dir/"analysis/groups.csv").open("w",newline="",encoding="utf-8-sig") as f:
            w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
    print(json.dumps(out,ensure_ascii=False,indent=2))


if __name__=="__main__":main()
